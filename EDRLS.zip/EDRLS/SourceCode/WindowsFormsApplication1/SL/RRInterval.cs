﻿using System;

namespace SL
{
    public class RRInterval
    {
        public class Point{
            public double X;
            public double Y;

            public Point(double x, double y)
            {
                X = x;
                Y = y;
            }
        }

        public Point FirstPoint;
        public Point LastPoint;
        public int Interval;

        public RRInterval(Point firstPoint, Point lastPoint)
        {
            FirstPoint = firstPoint;
            LastPoint = lastPoint;
            Interval = CalculateInterval(FirstPoint, LastPoint);
        }

        public RRInterval()
        {
            FirstPoint = new Point(0.0,0.0);
            LastPoint = new Point(0.0,0.0);
            Interval = 0;
        }

        private int CalculateInterval(Point first, Point last)
        {
            return (int) Math.Abs(first.X - last.X);
        }
    }
}
