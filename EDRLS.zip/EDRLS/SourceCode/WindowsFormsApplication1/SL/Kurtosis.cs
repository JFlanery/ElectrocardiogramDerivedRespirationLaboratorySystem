﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using SL;

namespace SL
{
    public class Kurtosis
    {

        public List<DataPoint> Points;
        public Kurtosis(IEnumerable<DataPoint> points)
        {
            LoadPoints(points);
        }

        public List<DataPoint> Calculate()
        {
            var kurtosis = new List<DataPoint>();
            var res = new List<DataPoint>();
            try
            {
                var peaks = PeakFinderImpl.FindPeaks(Points, 0.0,
                    Points.Select(dataPoint => dataPoint.YValues[0]).Concat(new[] {0.0}).Max()*.55, 0.0);
                for (var i = 0; i < peaks.Count-1; i++)
                {
                    var points = new List<DataPoint>();
                    for (var start = peaks[i].XValue*500; start < peaks[i + 1].XValue * 500; start++)
                    {
                        points.Add(new DataPoint(Points[(int)start].XValue, Points[(int)start].YValues));
                    }
                    var mean = points.Average(x => x.YValues[0]);
                    var kurtosisPoints = points.Select(p =>
                        new DataPoint(
                            p.XValue, Math.Pow(p.YValues[0] - mean, 4))).ToList();
                    var kurtosisSum = kurtosisPoints.Sum(x => x.YValues[0]);
                    var kurtosisStdDev = PeakFinderImpl.StdDev(kurtosisPoints, mean);
                    var kurtosisD = (kurtosisPoints.Count - 1)*Math.Pow(kurtosisStdDev, 4);
                    kurtosis.Add(new DataPoint(i, kurtosisSum/kurtosisD));
                }

                const int gamma = 0;
                const int variance = 1;
                for (var i = 0; i < kurtosis.Count; i++)
                {
                    var first = Math.Pow(variance, 2)*1;
                    var second = gamma - 3*Math.Pow(variance, 2);
                    var numerator = Math.Abs(first + (second*kurtosis[i].YValues[0]));
                    numerator = Math.Pow(numerator, 0.5) - variance*1;
                    var denominator = Math.Abs(second);
                    res.Add(new DataPoint(i, Math.Pow(numerator/denominator, 0.5)));
                }
            }
            catch (Exception e)
            {
                e.Message.ToString();
            }
            //var resMean = res.Average(x => x.YValues[0]);
            //foreach (var point in res)
            //{
            //    point.YValues[0] = point.YValues[0] - resMean;
            //}
            return res;
        }

        public List<DataPoint> Calculate(IEnumerable<DataPoint> points)
        {
            LoadPoints(points);
            return Calculate();
        }

        public void LoadPoints(IEnumerable<DataPoint> points)
        {
            Points = new List<DataPoint>();
            foreach (var p in points)
            {
                Points.Add(new DataPoint(p.XValue, p.YValues));
            }
        }
    }
}
