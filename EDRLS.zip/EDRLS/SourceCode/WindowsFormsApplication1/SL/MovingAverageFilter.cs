﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SL
{
    public class MovingAverageFilter
    {
        private readonly Queue<Double> _queue;
        public int WindowSize { get; private set; }
        public MovingAverageFilter(int windowSize)
        {
            if (windowSize < 2)
                throw new ArgumentException("windowSize must be greater then 1");
            WindowSize = windowSize;
            _queue = new Queue<double>(windowSize);
        }

        public double? Process(double value)
        {
            _queue.Enqueue(value);
            if (_queue.Count < WindowSize)
                return null;
            _queue.Dequeue();
            return _queue.Average();
        }
    }
}
