﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace SL
{
	public class ButterWorth
	{
		public enum Type { LowPass, HighPass, BandPass, StopPass };

		private List<double> X;
		private List<double> Y;
		public List<double> Coefficients;
		public double Gain;
		public int Order;
		public int SampleFreq;
		public int CornerFreq;
		public Type FilterType;

		public ButterWorth(int order, int sampleFreq, int cornerFreq, Type type)
		{
			this.Order = order;
			this.SampleFreq = sampleFreq;
			this.CornerFreq = cornerFreq;
			this.FilterType = type;

			AllowedValuesCheck();

			switch (type)
			{
				case Type.LowPass:
					X = Enumerable.Repeat(0.0, order+1).ToList();
					Y = Enumerable.Repeat(0.0, order + 1).ToList();
					Coefficients = Enumerable.Repeat(0.0, order).ToList();
					LowPassTypeCoefficients();
					break;
				case Type.HighPass:
					X = Enumerable.Repeat(0.0, order+1).ToList();
					Y = Enumerable.Repeat(0.0, order + 1).ToList();
					Coefficients = Enumerable.Repeat(0.0, order).ToList();
					HighPassTypeCoefficients();
					break;
				case Type.BandPass:
					X = Enumerable.Repeat(0.0, 2*order+1).ToList();
					Y = Enumerable.Repeat(0.0, 2 * order + 1).ToList();
					Coefficients = Enumerable.Repeat(0.0, 2 * order).ToList();
					BandPassTypeCoefficients();
					break;
				case Type.StopPass:
					X = Enumerable.Repeat(0.0, 2 * order + 1).ToList();
					Y = Enumerable.Repeat(0.0, 2 * order + 1).ToList();
					Coefficients = Enumerable.Repeat(0.0, 2 * order).ToList();
					StopPassTypeCoefficients();
					break;
				default:
					//should never hit here
					throw new FormatException("The Type of filter entered was incorrect");
			}
		}

		public double FilterValue(double val)
		{

			for (int i = 0; i < Order; i++)
			{
				X[i] = X[i + 1];
				Y[i] = Y[i + 1];
			}
			X[Order] = val / Gain;

			switch (FilterType)
			{
				case Type.LowPass:
					return LowPassAlgorithm();
				case Type.HighPass:
					return HighPassAlgorithm();
				case Type.BandPass:
					return 0.0;
				case Type.StopPass:
					return 0.0;
				default:
					return 0.0;
			}
		}

		//bilinear transform
		private double LowPassAlgorithm()
		{
			Y[Order] = X[0] + X[4]
				+ 4 * (X[1] + X[3])
				+ 6 * X[2]
				+ Coefficients[0] * Y[0]
				+ Coefficients[1] * Y[1]
				+ Coefficients[2] * Y[2]
				+ Coefficients[3] * Y[3];
			return Y[Order];
		}

		//bilinear transform
		private double HighPassAlgorithm()
		{
			Y[Order] = X[0] + X[4]
				- 4 * (X[1] + X[3])
				+ 6 * X[2]
				+ Coefficients[0] * Y[0]
				+ Coefficients[1] * Y[1]
				+ Coefficients[2] * Y[2]
				+ Coefficients[3] * Y[3];
			return Y[Order];
		}

		/**
		 * Only acceptable values at this time is 4th Order, 500Hz Sampling Freq, and a %0Hz corner Freq
		 */
		private void LowPassTypeCoefficients(){
			switch(CornerFreq){
				case 20:
                    Gain = 5.458037903e+03;
					Coefficients[0] = -0.5174781998;
					Coefficients[1] = 2.4093428566;
					Coefficients[2] = -4.2388639509;
					Coefficients[3] = 3.3440678377;
					break;
				case 8:
                    Gain = 1.780448518e+05;
					Coefficients[0] = -0.7688727439;
					Coefficients[1] = 3.2774327939;
					Coefficients[2] = -5.2460033060;
					Coefficients[3] = 3.7373533910;
					break;
				case 5:
                    Gain = 1.112983215e+06;
					Coefficients[0] = -0.8485559993;
					Coefficients[1] = 3.5335352195;
					Coefficients[2] = -5.5208191366;
					Coefficients[3] = 3.8358255406;
					break;
				default:
					//should never hit here
					break;
			}
		}

		private void HighPassTypeCoefficients(){
			switch (CornerFreq)
			{
				case 20:
                    Gain = 1.390125419e+00;
					Coefficients[0] = -0.5174781998;
					Coefficients[1] = 2.4093428566;
					Coefficients[2] = -4.2388639509;
					Coefficients[3] = 3.3440678377;
					break;
				case 8:
                    Gain = 1.140440855e+00;
					Coefficients[0] = -0.7688727439;
					Coefficients[1] = 3.2774327939;
					Coefficients[2] = -5.2460033060;
					Coefficients[3] = 3.7373533910;
					break;
				case 5:
                    Gain = 1.085574782e+00;
					Coefficients[0] = -0.8485559993;
					Coefficients[1] = 3.5335352195;
					Coefficients[2] = -5.5208191366;
					Coefficients[3] = 3.8358255406;
					break;
				default:
					//should never hit here
					break;
			}
		}

		private void BandPassTypeCoefficients(){

		}

		private void StopPassTypeCoefficients(){


		}

		private void AllowedValuesCheck()
		{
			if (FilterType == Type.BandPass || FilterType == Type.StopPass)
				throw new ArgumentOutOfRangeException("FilterType", FilterType, "Is not of an acceptable value");
			if (Order != 4)
				throw new ArgumentOutOfRangeException("order", Order, "Is not of an acceptable value");
			if (SampleFreq != 500)
				throw new ArgumentOutOfRangeException("sampleFreq", SampleFreq, "Is not of an acceptable value");
			if (!(CornerFreq == 20 || CornerFreq == 8 || CornerFreq == 5))
				throw new ArgumentOutOfRangeException("cornerFreq", CornerFreq, "Is not of an acceptable value");
		}
	}
}
