﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;

namespace SL
{
    internal class FiltFilt
    {

        public static void Filter(IList<double> aCoefficients, IList<IList<double>> bCoefficients,
            IList<DataPoint> values)
        {
            if (!aCoefficients.Any() || !bCoefficients.Any() || !values.Any())
                return;
            var npts = values.Count;
            var nchans = values.Count;

            var obj = GetCoeffsAndInitialConditions(aCoefficients, bCoefficients, npts);
            //Todo: change these to their actual types
            object y;
            object zi = null;
            object nfact = null;
            object L = null;
            object b = null;
            object a = null;
            object x = null;
            if (nchans == 1)
            {
                y = npts < 10000
                    ? ffOneChanCat(bCoefficients, aCoefficients, values, zi, nfact, L)
                    : ffOneChan(bCoefficients, aCoefficients, values, zi, nfact, L);
            }
            else
            {
                y = ffMultiChan(bCoefficients, aCoefficients, values, zi, nfact, L);
            }
        }

        private static object ffMultiChan(object o, object o1, object o2, object zi, object nfact, object o3)
        {
            throw new NotImplementedException();
        }

        private static object ffOneChanCat(IList<IList<double>> bCoefficients, IList<double> aCoefficients, IList<DataPoint> values, object zi, object nfact, object p5)
        {
            throw new NotImplementedException();
        }

        private static object ffOneChan(IList<IList<double>> bCoefficients, IList<double> aCoefficients, IList<DataPoint> values, object zi, object nfact, object p5)
        {
            throw new NotImplementedException();
        }

        //Todo: change to actual return type
        public static Object GetCoeffsAndInitialConditions(IList<double> aCoefficients,
            IList<IList<double>> bCoefficients,
            int npts)
        {
            var l = bCoefficients.Count;
            var ncols = bCoefficients.Count;
            var na = aCoefficients.Count;
            var b = new Matrix(l, 6);
            var a = new Matrix(l, 6);
            var nfact = 0;
            Matrix zi;
            var nb = bCoefficients.Count;

            //warning
            if (ncols == 6 && l == 1 && na <= 2)
            {
                //ToDo - Figure out what to do with this warning
            }

            var isos = ncols == 6 && (l > 1 || (b.Get(4) == 1.0 && na <= 2));

            if (isos)
            {
                var g = aCoefficients.ToList();
                var ng = na;

                if (ng > (l + 1))
                {
                    //ToDo: Error Message here
                }
                else if (ng == (l + 1))
                {
                    for (var col = 1; col <= 3; col++)
                    {
                        b.Set(g[l + 1]*b.Get(l, col), l, col);
                    }
                    ng = ng - 1;
                }

                for (var row = 1; row <= ng; row++)
                {
                    for (var col = 1; col <= 3; col++)
                    {
                        b.Set(g[row]*b.Get(row, col), row, col);
                    }
                }
                for (var row = 1; row <= b.RowSize; row++)
                {
                    for (var col = 4; col <= 6; col++)
                    {
                        a.Set(b.Get(row, col), row, col - 3);
                        b.Set(b.Get(row, col - 3), row, col - 3);
                    }
                }
                nfact = 6;
                if (npts <= nfact)
                {
                    //ToDo: Error Message
                }

                zi = Matrix.Zeros(2, l);
                var tempMatrix = new Matrix(2, 1);
                tempMatrix.Set(1, 1, 1);
                tempMatrix.Set(0, 2, 1);
                for (var col = 1; col <= l; col++)
                {
                    var rhs = b.SubMatrix(2, 3, col, col).Subtract(
                        b.SubMatrix(1, 1, col, col).Multiply(
                            a.SubMatrix(2, 3, col, col)));
                    var subMatrix = a.SubMatrix(2, 3, col, col).Append(tempMatrix);
                    subMatrix = Matrix.Eye(2).Subtract(subMatrix).Multiply(rhs.Inverse());
                    for (var row = 1; row <= subMatrix.RowSize; row++)
                    {
                        zi.Set(subMatrix.Get(row, col), row, col);
                    }
                }
            }
            else
            {
                l = 1;
                nb = bCoefficients.Count;
                var nfilt = Math.Max(nb, na);
                nfact = 3*(nfilt - 1);
                if (npts <= nfact)
                    //ToDo: Error Message Here
                    if (nb < nfilt)
                        b.Set(0, nfilt, 1);
                    else if (na < nfilt)
                        a.Set(0, nfilt, 1);
                if (nfilt > 1)
                {
                    //rows
                    //cols
                    //vals
                    //rhs
                    //zi
                }
                else
                {
                    zi = Matrix.Zeros(0, 1);
                }
            }
            return null;
        }
    }



    internal class Matrix
    {
        private readonly IList<IList<double>> _matrix;
        public int RowSize { get; private set; }
        public int ColSize { get; private set; }
        public int Count { get; private set; }

        public Matrix(int rowSize, int colSize)
        {
            _matrix = new List<IList<double>>();
            for (var i = 1; i <= rowSize; i++)
                _matrix.Add(new List<double>(colSize));
            RowSize = rowSize;
            ColSize = colSize;
            Count = 0;
        }

        public bool Add(double value)
        {
            if (Count == RowSize*ColSize) return false;
            _matrix[Count/ColSize][Count%ColSize] = value;
            Count++;
            return true;
        }

        public void Set(double value, int row, int col)
        {
            _matrix[row - 1][col - 1] = value;
        }

        public void Set(double value, int position)
        {
            _matrix[position/ColSize][(position - 1)%ColSize] = value;
        }

        public double Get(int position)
        {
            return _matrix[position/ColSize][(position - 1)%ColSize];
        }

        public double Get(int row, int col)
        {
            return _matrix[row - 1][col - 1];
        }

        public static Matrix Zeros(int rowSize, int colSize)
        {
            var retVal = new Matrix(rowSize, colSize);
            for (var row = 1; row <= rowSize; row++)
            {
                for (var col = 1; col <= colSize; col++)
                {
                    retVal.Set(0.0, row, col);
                }
            }
            return retVal;
        }

        public static Matrix Eye(int size)
        {
            var retVal = Zeros(size, size);
            for (var row = 1; row <= size; row++)
            {
                retVal.Set(1, row, row);
            }
            return retVal;
        }

        public double Determinate()
        {
            if (RowSize != ColSize)
                throw new ArgumentException("Matrix must be square");
            if (RowSize == 2 && ColSize == 2)
                return _matrix[1][1]*_matrix[2][2] - _matrix[1][2]*_matrix[2][1];
            var minor = new Matrix(RowSize, ColSize);
            var retVal = 0.0;
            for (var col = 1; col <= ColSize; col++)
            {
                retVal += _matrix[1][col]*DetermHelper(1, col).Determinate()*Math.Pow(-1, 1 + col);
            }
            return retVal;
        }

        /// <summary>
        /// This method is responsible for getting the submatrix for a determinate by
        /// excluding the row and column appropriately
        /// </summary>
        /// <returns></returns>
        private Matrix DetermHelper(int rowExclusion, int colExclusion)
        {
            var retVal = new Matrix(RowSize - 1, ColSize - 1);
            for (int row = 1, detRow = 1; row <= RowSize; row++)
            {
                if (row == rowExclusion)
                    continue;
                for (int col = 1, detCol = 1; col <= ColSize; col++)
                {
                    if (col == colExclusion)
                        continue;
                    retVal.Set(_matrix[row - 1][col - 1], detRow, detCol);
                    detCol++;
                }
                detRow++;
            }
            return retVal;
        }

        public Matrix SubMatrix(int rowStart, int rowEnd, int colStart, int colEnd)
        {
            if (rowEnd <= rowStart)
                throw new ArgumentException("rowEnd must be larger then rowStart", "rowEnd");
            if (colEnd <= colStart)
                throw new ArgumentException("colEnd must be larger then colStart", "colStart");
            if (rowStart <= 0)
                throw new ArgumentException("parameter has to be greater then 0", "rowStart");
            if (rowEnd <= 0)
                throw new ArgumentException("parameter has to be greater then 0", "rowEnd");
            if (colStart <= 0)
                throw new ArgumentException("parameter has to be greater then 0", "colStart");
            if (colEnd <= 0)
                throw new ArgumentException("parameter has to be greater then 0", "colEnd");
            if (RowSize < rowEnd)
                throw new ArgumentException("rowEnd is larger then the number of rows", "rowEnd");
            if (ColSize < colEnd)
                throw new ArgumentException("colEnd is larger then the number of columns", "colEnd");

            var retVal = new Matrix(rowEnd - rowStart, colEnd - colStart);
            for (var row = 1; row <= rowEnd - rowStart; row++)
            {
                for (var col = 1; col <= colEnd - colStart; col++)
                {
                    retVal.Set(_matrix[rowStart - 1 + row][colStart - 1 + col], row, col);
                }
            }

            return retVal;
        }

        public Matrix Inverse()
        {
            if (ColSize != RowSize)
                throw new ArgumentException("Must be a square matrix");
            var det = Determinate();
            var minMat = MatrixOfMinor();
            for (var i = 1; i <= RowSize; i++)
            {
                for (var j = i; j <= ColSize; j++)
                {
                    if (i == j) continue;
                    var tempVal = minMat.Get(i, j);
                    minMat.Set(minMat.Get(j, i), i, j);
                    minMat.Set(tempVal, j, i);
                }
            }

            for (var i = 1; i <= RowSize; i++)
            {
                for (var j = 1; j <= ColSize; j++)
                {
                    minMat.Set(minMat.Get(i, j)/det, i, j);
                }
            }

            return minMat;
        }

        public Matrix MatrixOfMinor()
        {
            if (RowSize != ColSize)
                throw new ArgumentException("Matrix must be square");
            if (RowSize == 2 && ColSize == 2) return null;
            var tempMat = new Matrix(RowSize, ColSize);
            for (var i = 1; i < RowSize; i++)
            {
                for (var j = 1; j < ColSize; j++)
                {
                    tempMat.Set(DetermHelper(i, j).Determinate()*Math.Pow(-1, i + j), i, j);
                }
            }
            return tempMat;
        }

        public Matrix Divide(Matrix input)
        {
            return Multiply(input.Inverse());
        }

        public Matrix Multiply(Matrix input)
        {
            if (ColSize != RowSize)
                throw new ArgumentException("The col size and row size of the two matrices do not match");
            var newMatrix = new Matrix(RowSize, input.ColSize);
            for (var i = 1; i <= RowSize; i++)
            {
                var row = SubMatrix(i, i, 1, ColSize);
                for (var j = 1; j <= input.ColSize; j++)
                {
                    var col = input.SubMatrix(1, RowSize, j, j);
                    newMatrix.Set(DotProduct(row, col), i, j);
                }
            }
            return newMatrix;
        }

        public Matrix Add(Matrix input)
        {
            if (RowSize != input.RowSize && ColSize != input.ColSize)
                throw new ArgumentException("Matrices don't have the same dimensions");
            var newMatrix = new Matrix(RowSize, ColSize);
            for (var i = 1; i <= RowSize; i++)
            {
                for (var j = 1; j <= ColSize; j++)
                {
                    newMatrix.Set(Get(i, j) + input.Get(i, j), i, j);
                }
            }

            return newMatrix;
        }

        public Matrix Subtract(Matrix input)
        {
            if (RowSize != input.RowSize && ColSize != input.ColSize)
                throw new ArgumentException("Matrices don't have the same dimensions");
            var newMatrix = new Matrix(RowSize, ColSize);
            for (var i = 1; i <= RowSize; i++)
            {
                for (var j = 1; j <= ColSize; j++)
                {
                    newMatrix.Set(Get(i, j) - input.Get(i, j), i, j);
                }
            }

            return newMatrix;
        }

        public double DotProduct(Matrix vector1, Matrix vector2)
        {
            var retVal = 0.0;
            var loopEnd = Math.Max(Math.Max(vector1.RowSize, vector2.RowSize),
                Math.Max(vector1.ColSize, vector2.ColSize));
            for (var i = 1; i <= loopEnd; i++)
            {
                retVal += vector1.Get(i)*vector2.Get(i);
            }
            return retVal;
        }

        public Matrix Multiply(double value)
        {
            var retVal = new Matrix(RowSize, ColSize);
            for (var row = 1; row <= RowSize; row++)
            {
                for (var col = 1; col <= ColSize; col++)
                {
                    retVal.Set(Get(row, col)*value, row, col);
                }
            }
            return retVal;
        }

        public Matrix Append(Matrix toAppend)
        {
            var retVal = new Matrix(RowSize + toAppend.RowSize, ColSize + toAppend.ColSize);
            for (var row = 1; row <= RowSize; row++)
            {
                for (var col = 1; col <= ColSize; col++)
                {
                    retVal.Set(Get(row,col), row, col);
                }
            }

            for (var row = 1; row <= toAppend.RowSize; row++)
            {
                for (var col = 1; col <= toAppend.ColSize; col++)
                {
                    retVal.Set(Get(row, col), row + RowSize, col + ColSize);
                }
            }
            return retVal;
        }
    
    }
}
