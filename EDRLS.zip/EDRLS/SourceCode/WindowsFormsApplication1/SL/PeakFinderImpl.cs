﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SL
{
    public class PeakFinderImpl
    {

        #region FindPeaks
		public static IList<DataPoint> FindPeaks(IList<DataPoint> rawData, double amplThreshold, double slopeThreshold)
        {
			return FindPeaks(rawData, StdDev(rawData), Mean(rawData), amplThreshold, slopeThreshold);
        }

		public static IList<DataPoint> FindPeaks(IList<DataPoint> rawData, double mean, double amplThreshold, double slopeThreshold)
		{
			return FindPeaks(rawData, mean, StdDev(rawData, mean), amplThreshold, slopeThreshold);
		}

		public static IList<DataPoint> FindPeaks(IList<DataPoint> rawData, double mean, double stdDev, double amplThreshold, double slopeThreshold)
		{
			IList<DataPoint> peakHolder = new List<DataPoint>();
			DataPoint peak = null;
			var count = 0;

			for (var i = 0; i < rawData.Count-2; i++)
			{
			    if (!(rawData[i].YValues[0] >= amplThreshold)) continue;
			    if (peak == null)
			    {
			        peak = rawData[i];
			    }
			    else if (rawData[i].YValues[0] < rawData[i + 1].YValues[0] || rawData[i].YValues[0] < rawData[Math.Max(0, i-1)].YValues[0])
			    {
			        peak = rawData[i];
			    }
			    else if (rawData[i].YValues[0] == peak.YValues[0])
			    {
			        count++;
			    }
			    else
			    {
			        if (!(Math.Abs(CalculateSlope(rawData[i], rawData[i - count + 5])) >= slopeThreshold)) continue;
			        peakHolder.Add(rawData[i - count/2]);
			        count = 0;
			        peak = null;
			    }
			}

			return peakHolder;
		}
		#endregion

        #region ZScore
		public static IList<DataPoint> ZScore(IList<DataPoint> rawData, double mean, double stdDev)
        {
			var PeakList = new List<DataPoint>();
			foreach (var p in rawData)
			{
				PeakList.Add(new DataPoint(p.XValue, (p.YValues[0]-mean)/stdDev));
			}
			return PeakList;
        }

		public static IList<DataPoint> ZScore(IList<DataPoint> rawData, double mean)
        {
            return ZScore(rawData, mean, StdDev(rawData, mean));
        }

		public static IList<DataPoint> ZScore(IList<DataPoint> rawData)
        {
            double mean = Mean(rawData);
            return ZScore(rawData, mean, StdDev(rawData, mean));
        }
		#endregion

        #region StdDev
        public static double StdDev(IList<DataPoint> rawData)
        {
			if(rawData.Count < 3) return -1.0;
            return StdDev(rawData, Mean(rawData));
        }

        public static double StdDev(IList<DataPoint> rawData, double mean)
        {
			if (rawData.Count < 3) return -1.0;
			var stdDevVal = rawData.Sum(p => Math.Pow(p.YValues[0] - mean, 2));
            return Math.Sqrt(1.0 / rawData.Count * stdDevVal);
        }
        #endregion

        public static double Mean(IList<DataPoint> rawData)
        {
			if (rawData.Count < 1) return -1.0;
            double mean = 0;
            
            foreach (DataPoint p in rawData)
            {
				mean += p.YValues[0];
            }

            return mean / rawData.Count;
        }

		public static double CalculateSlope(DataPoint start, DataPoint end)
        {
            var numerator = end.XValue - start.XValue;
			var denominator = end.YValues[0] - start.YValues[0];
            return numerator/denominator;
        }
    }
}
