﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using DL;
using SL;
using Timer = System.Windows.Forms.Timer;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections.Generic;
using ButterWorth = SL.ButterWorth;

namespace WindowsFormsApplication1
{
	/// <summary>
	/// Summary description for RealTimeData
	/// </summary>
	/// public class RealTimeData : System.Windows.Forms.UserControl
	public class RealTimeData : Form
	{
		#region fields
		private System.ComponentModel.IContainer components;
        private List<DataPoint> _rawTI = new List<DataPoint>();
		private List<DataPoint> _rawEcg = new List<DataPoint>();
		IList<DataPoint> _peaks;
		bool _annotate;

	    private Timer _connectionCheck;

		#region chart1 fields
		private Chart _derivedChart;
		#endregion

		#region chart2 fields
		private Chart _tiChart;
		private Timer _tiTimer;
		#endregion

		#region file menu fields
		private MenuStrip _menuStrip2;
		private ToolStripMenuItem _fileToolStripMenuItem;
		private ToolStripMenuItem _saveToolStripMenuItem;
		private ToolStripMenuItem _loadToolStripMenuItem;
		private ToolStripMenuItem _exitToolStripMenuItem;
        private ToolStripMenuItem _filtersToolStripMenuItem;
	    private ToolStripMenuItem _helpToolStripMenuItem;
		private ToolStripMenuItem _documentationToolStripMenuItem;
		#endregion

		#region toolbar fields
		private ToolStrip _toolStrip1;
		#endregion

		#region timer fields
		private Button _buttonStart;
		private GroupBox _groupBox1;
		private Label _label1;
		private TextBox _secBox;
		private TextBox _minBox;
		private TextBox _hrsBox;
		private Label _label3;
		private Label _label2;
		private Label _label5;
		private Label _label4;
		private int _min;
		private int _sec;
		private int _hrs;
		private Label _label9;
		private Label _label8;
		private Label _secLabel;
		private Label _minLabel;
		private Label _hrsLabel;
		private Timer _timer1;
		#endregion

		#region Chart3 fields
		// Chart data adding thread
	    private bool _running;

		// Thread Add Data delegate
		public delegate void AddDataDelegate();
		public AddDataDelegate AddDataDel;

		// Chart control
        private Chart _ecgChart;
        private Label label1;
        private Label label2;
        private Label label3;
        private static TextBox _minTextBox;
        private static TextBox _maxTextBox;
        private static TextBox _meanTextBox;
        private ToolStripMenuItem ECGLoad;
        private ToolStripMenuItem TILoad;
        private ToolStripMenuItem ECGTILoad;
        private ToolStripButton openToolStripButton;
        private ToolStripButton saveToolStripButton;
        private ToolStripSeparator toolStripSeparator;
        private ToolStripButton helpToolStripButton;
        private TreeView AppliedFilterView;

	    private Timer _refreshTimer;
		#endregion
		#endregion

		#region form functions
		public RealTimeData()
		{
		    _peaks = null;
		    // This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
            AppliedFilterView.Nodes[0].ExpandAll();
		}


	    /// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		#endregion //form functions

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RealTimeData));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Type: None");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Freq: None");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Digital Filter:", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Moving Average: Off");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("ECG Filtering", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Moving Average: Off");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("TI Filtering", new System.Windows.Forms.TreeNode[] {
            treeNode6});
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Applied Filters", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode7});
            this._derivedChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this._menuStrip2 = new System.Windows.Forms.MenuStrip();
            this._fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ECGLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.TILoad = new System.Windows.Forms.ToolStripMenuItem();
            this.ECGTILoad = new System.Windows.Forms.ToolStripMenuItem();
            this._exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._filtersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._documentationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._ecgChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this._groupBox1 = new System.Windows.Forms.GroupBox();
            this._label9 = new System.Windows.Forms.Label();
            this._label8 = new System.Windows.Forms.Label();
            this._secLabel = new System.Windows.Forms.Label();
            this._minLabel = new System.Windows.Forms.Label();
            this._hrsLabel = new System.Windows.Forms.Label();
            this._label5 = new System.Windows.Forms.Label();
            this._label4 = new System.Windows.Forms.Label();
            this._label3 = new System.Windows.Forms.Label();
            this._label2 = new System.Windows.Forms.Label();
            this._label1 = new System.Windows.Forms.Label();
            this._secBox = new System.Windows.Forms.TextBox();
            this._minBox = new System.Windows.Forms.TextBox();
            this._hrsBox = new System.Windows.Forms.TextBox();
            this._buttonStart = new System.Windows.Forms.Button();
            this._tiChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this._timer1 = new System.Windows.Forms.Timer(this.components);
            this._tiTimer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this._refreshTimer = new System.Windows.Forms.Timer(this.components);
            this._connectionCheck = new System.Windows.Forms.Timer(this.components);
            this.AppliedFilterView = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this._derivedChart)).BeginInit();
            this._menuStrip2.SuspendLayout();
            this._toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._ecgChart)).BeginInit();
            this._groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._tiChart)).BeginInit();
            this.SuspendLayout();
            // 
            // _derivedChart
            // 
            this._derivedChart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(223)))), ((int)(((byte)(193)))));
            this._derivedChart.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this._derivedChart.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(64)))), ((int)(((byte)(1)))));
            this._derivedChart.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            this._derivedChart.BorderlineWidth = 2;
            this._derivedChart.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.Emboss;
            chartArea1.Area3DStyle.Inclination = 15;
            chartArea1.Area3DStyle.IsClustered = true;
            chartArea1.Area3DStyle.IsRightAngleAxes = false;
            chartArea1.Area3DStyle.Perspective = 10;
            chartArea1.Area3DStyle.Rotation = 10;
            chartArea1.Area3DStyle.WallWidth = 0;
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea1.AxisX.LabelStyle.Format = "#.##";
            chartArea1.AxisX.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.AxisX.Maximum = 20D;
            chartArea1.AxisX.Title = "seconds (s)";
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea1.AxisY.LabelStyle.Format = "#.##";
            chartArea1.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.AxisY.Maximum = 3.5D;
            chartArea1.AxisY.Minimum = 0D;
            chartArea1.AxisY.Title = "Amplitude";
            chartArea1.BackColor = System.Drawing.Color.OldLace;
            chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea1.BackSecondaryColor = System.Drawing.Color.White;
            chartArea1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.CursorX.Interval = 0.02D;
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.CursorY.Interval = 0.02D;
            chartArea1.CursorY.IsUserEnabled = true;
            chartArea1.CursorY.IsUserSelectionEnabled = true;
            chartArea1.Name = "Default";
            chartArea1.ShadowColor = System.Drawing.Color.Transparent;
            this._derivedChart.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Enabled = false;
            legend1.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            legend1.IsTextAutoFit = false;
            legend1.Name = "Default";
            this._derivedChart.Legends.Add(legend1);
            this._derivedChart.Location = new System.Drawing.Point(244, 295);
            this._derivedChart.Name = "_derivedChart";
            series1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            series1.ChartArea = "Default";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Default";
            series1.Name = "Default";
            this._derivedChart.Series.Add(series1);
            this._derivedChart.Size = new System.Drawing.Size(1018, 248);
            this._derivedChart.TabIndex = 1;
            title1.Name = "ECG-Derived";
            title1.Text = "ECG-Derived Respiration";
            this._derivedChart.Titles.Add(title1);
            this._derivedChart.CursorPositionChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.CursorEventArgs>(this.Zoom);
            this._derivedChart.AxisViewChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ViewEventArgs>(this.ResetInterval);
            // 
            // _menuStrip2
            // 
            this._menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._fileToolStripMenuItem,
            this._filtersToolStripMenuItem,
            this._helpToolStripMenuItem});
            this._menuStrip2.Location = new System.Drawing.Point(0, 0);
            this._menuStrip2.Name = "_menuStrip2";
            this._menuStrip2.Size = new System.Drawing.Size(1277, 28);
            this._menuStrip2.TabIndex = 3;
            this._menuStrip2.Text = "menuStrip2";
            // 
            // _fileToolStripMenuItem
            // 
            this._fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._saveToolStripMenuItem,
            this._loadToolStripMenuItem,
            this._exitToolStripMenuItem});
            this._fileToolStripMenuItem.Name = "_fileToolStripMenuItem";
            this._fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this._fileToolStripMenuItem.Text = "File";
            // 
            // _saveToolStripMenuItem
            // 
            this._saveToolStripMenuItem.Name = "_saveToolStripMenuItem";
            this._saveToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this._saveToolStripMenuItem.Text = "save";
            this._saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripButton_Click_1);
            // 
            // _loadToolStripMenuItem
            // 
            this._loadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ECGLoad,
            this.TILoad,
            this.ECGTILoad});
            this._loadToolStripMenuItem.Name = "_loadToolStripMenuItem";
            this._loadToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this._loadToolStripMenuItem.Text = "load";
            this._loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // ECGLoad
            // 
            this.ECGLoad.Name = "ECGLoad";
            this.ECGLoad.Size = new System.Drawing.Size(135, 24);
            this.ECGLoad.Text = "ECG";
            this.ECGLoad.Click += new System.EventHandler(this.ECGLoad_Click);
            // 
            // TILoad
            // 
            this.TILoad.Name = "TILoad";
            this.TILoad.Size = new System.Drawing.Size(135, 24);
            this.TILoad.Text = "TI";
            this.TILoad.Click += new System.EventHandler(this.TILoad_Click);
            // 
            // ECGTILoad
            // 
            this.ECGTILoad.Name = "ECGTILoad";
            this.ECGTILoad.Size = new System.Drawing.Size(135, 24);
            this.ECGTILoad.Text = "ECG + TI";
            this.ECGTILoad.Click += new System.EventHandler(this.ECGTILoad_Click);
            // 
            // _exitToolStripMenuItem
            // 
            this._exitToolStripMenuItem.Name = "_exitToolStripMenuItem";
            this._exitToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this._exitToolStripMenuItem.Text = "exit";
            this._exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // _filtersToolStripMenuItem
            // 
            this._filtersToolStripMenuItem.Name = "_filtersToolStripMenuItem";
            this._filtersToolStripMenuItem.Size = new System.Drawing.Size(60, 24);
            this._filtersToolStripMenuItem.Text = "Filters";
            this._filtersToolStripMenuItem.Click += new System.EventHandler(this._filtersToolStripMenuItem_Click);
            // 
            // _helpToolStripMenuItem
            // 
            this._helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._documentationToolStripMenuItem});
            this._helpToolStripMenuItem.Name = "_helpToolStripMenuItem";
            this._helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this._helpToolStripMenuItem.Text = "Help";
            // 
            // _documentationToolStripMenuItem
            // 
            this._documentationToolStripMenuItem.Name = "_documentationToolStripMenuItem";
            this._documentationToolStripMenuItem.Size = new System.Drawing.Size(160, 24);
            this._documentationToolStripMenuItem.Text = "User Manual";
            this._documentationToolStripMenuItem.Click += new System.EventHandler(this.documentationToolStripMenuItem_Click);
            // 
            // _toolStrip1
            // 
            this._toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripButton,
            this.saveToolStripButton,
            this.toolStripSeparator,
            this.helpToolStripButton});
            this._toolStrip1.Location = new System.Drawing.Point(0, 28);
            this._toolStrip1.Name = "_toolStrip1";
            this._toolStrip1.Size = new System.Drawing.Size(1277, 25);
            this._toolStrip1.Stretch = true;
            this._toolStrip1.TabIndex = 7;
            this._toolStrip1.Text = "toolStrip1";
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openToolStripButton.Text = "&Open";
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "&Save";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.helpToolStripButton.Text = "He&lp";
            // 
            // _ecgChart
            // 
            this._ecgChart.BackColor = System.Drawing.Color.Aqua;
            this._ecgChart.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this._ecgChart.BackSecondaryColor = System.Drawing.Color.White;
            this._ecgChart.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            this._ecgChart.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            this._ecgChart.BorderlineWidth = 2;
            this._ecgChart.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.Emboss;
            chartArea2.Area3DStyle.Inclination = 15;
            chartArea2.Area3DStyle.IsClustered = true;
            chartArea2.Area3DStyle.IsRightAngleAxes = false;
            chartArea2.Area3DStyle.Perspective = 10;
            chartArea2.Area3DStyle.Rotation = 10;
            chartArea2.Area3DStyle.WallWidth = 0;
            chartArea2.AxisX.Interval = 1D;
            chartArea2.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea2.AxisX.LabelStyle.Format = "#.##";
            chartArea2.AxisX.Maximum = 15D;
            chartArea2.AxisX.Minimum = 0D;
            chartArea2.AxisX.Title = "seconds (s)";
            chartArea2.AxisX2.ScrollBar.BackColor = System.Drawing.Color.Silver;
            chartArea2.AxisX2.ScrollBar.ButtonColor = System.Drawing.Color.Black;
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.IsStartedFromZero = false;
            chartArea2.AxisY.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea2.AxisY.LabelStyle.Format = "#.##";
            chartArea2.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisY.Maximum = 10D;
            chartArea2.AxisY.Minimum = -10D;
            chartArea2.AxisY.Title = "Voltage (mV)";
            chartArea2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(165)))), ((int)(((byte)(191)))), ((int)(((byte)(228)))));
            chartArea2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea2.BackSecondaryColor = System.Drawing.Color.White;
            chartArea2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea2.CursorX.Interval = 0.02D;
            chartArea2.CursorX.IsUserEnabled = true;
            chartArea2.CursorX.IsUserSelectionEnabled = true;
            chartArea2.CursorY.Interval = 0.02D;
            chartArea2.CursorY.IsUserEnabled = true;
            chartArea2.CursorY.IsUserSelectionEnabled = true;
            chartArea2.Name = "Default";
            chartArea2.ShadowColor = System.Drawing.Color.Transparent;
            this._ecgChart.ChartAreas.Add(chartArea2);
            legend2.Enabled = false;
            legend2.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            legend2.IsTextAutoFit = false;
            legend2.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Row;
            legend2.Name = "Default";
            this._ecgChart.Legends.Add(legend2);
            this._ecgChart.Location = new System.Drawing.Point(244, 56);
            this._ecgChart.Name = "_ecgChart";
            series2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            series2.ChartArea = "Default";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(64)))), ((int)(((byte)(10)))));
            series2.Legend = "Default";
            series2.Name = "series2";
            series2.ShadowOffset = 1;
            this._ecgChart.Series.Add(series2);
            this._ecgChart.Size = new System.Drawing.Size(1018, 243);
            this._ecgChart.TabIndex = 1;
            title2.Name = "ECG - Signal";
            title2.Text = "Electrocardiogram (ECG)";
            this._ecgChart.Titles.Add(title2);
            this._ecgChart.CursorPositionChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.CursorEventArgs>(this.Zoom);
            this._ecgChart.AxisViewChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ViewEventArgs>(this.ResetInterval);
            // 
            // _groupBox1
            // 
            this._groupBox1.Controls.Add(this._label9);
            this._groupBox1.Controls.Add(this._label8);
            this._groupBox1.Controls.Add(this._secLabel);
            this._groupBox1.Controls.Add(this._minLabel);
            this._groupBox1.Controls.Add(this._hrsLabel);
            this._groupBox1.Controls.Add(this._label5);
            this._groupBox1.Controls.Add(this._label4);
            this._groupBox1.Controls.Add(this._label3);
            this._groupBox1.Controls.Add(this._label2);
            this._groupBox1.Controls.Add(this._label1);
            this._groupBox1.Controls.Add(this._secBox);
            this._groupBox1.Controls.Add(this._minBox);
            this._groupBox1.Controls.Add(this._hrsBox);
            this._groupBox1.Controls.Add(this._buttonStart);
            this._groupBox1.Location = new System.Drawing.Point(0, 56);
            this._groupBox1.Name = "_groupBox1";
            this._groupBox1.Size = new System.Drawing.Size(238, 194);
            this._groupBox1.TabIndex = 28;
            this._groupBox1.TabStop = false;
            this._groupBox1.Text = "Timer";
            // 
            // _label9
            // 
            this._label9.AutoSize = true;
            this._label9.Font = new System.Drawing.Font("Verdana", 18F);
            this._label9.Location = new System.Drawing.Point(142, 95);
            this._label9.Margin = new System.Windows.Forms.Padding(0);
            this._label9.Name = "_label9";
            this._label9.Size = new System.Drawing.Size(29, 36);
            this._label9.TabIndex = 19;
            this._label9.Text = ":";
            // 
            // _label8
            // 
            this._label8.AutoSize = true;
            this._label8.Font = new System.Drawing.Font("Verdana", 18F);
            this._label8.Location = new System.Drawing.Point(54, 95);
            this._label8.Margin = new System.Windows.Forms.Padding(0);
            this._label8.Name = "_label8";
            this._label8.Size = new System.Drawing.Size(29, 36);
            this._label8.TabIndex = 18;
            this._label8.Text = ":";
            // 
            // _secLabel
            // 
            this._secLabel.AutoSize = true;
            this._secLabel.Font = new System.Drawing.Font("Verdana", 18F);
            this._secLabel.Location = new System.Drawing.Point(165, 95);
            this._secLabel.Name = "_secLabel";
            this._secLabel.Size = new System.Drawing.Size(53, 36);
            this._secLabel.TabIndex = 17;
            this._secLabel.Text = "00";
            // 
            // _minLabel
            // 
            this._minLabel.AutoSize = true;
            this._minLabel.Font = new System.Drawing.Font("Verdana", 18F);
            this._minLabel.Location = new System.Drawing.Point(86, 95);
            this._minLabel.Name = "_minLabel";
            this._minLabel.Size = new System.Drawing.Size(53, 36);
            this._minLabel.TabIndex = 16;
            this._minLabel.Text = "00";
            // 
            // _hrsLabel
            // 
            this._hrsLabel.AutoSize = true;
            this._hrsLabel.Font = new System.Drawing.Font("Verdana", 18F);
            this._hrsLabel.Location = new System.Drawing.Point(6, 95);
            this._hrsLabel.Name = "_hrsLabel";
            this._hrsLabel.Size = new System.Drawing.Size(53, 36);
            this._hrsLabel.TabIndex = 15;
            this._hrsLabel.Text = "00";
            // 
            // _label5
            // 
            this._label5.AutoSize = true;
            this._label5.Location = new System.Drawing.Point(122, 64);
            this._label5.Name = "_label5";
            this._label5.Size = new System.Drawing.Size(33, 18);
            this._label5.TabIndex = 14;
            this._label5.Text = "sec";
            // 
            // _label4
            // 
            this._label4.AutoSize = true;
            this._label4.Location = new System.Drawing.Point(66, 64);
            this._label4.Name = "_label4";
            this._label4.Size = new System.Drawing.Size(35, 18);
            this._label4.TabIndex = 13;
            this._label4.Text = "min";
            // 
            // _label3
            // 
            this._label3.AutoSize = true;
            this._label3.Location = new System.Drawing.Point(17, 64);
            this._label3.Name = "_label3";
            this._label3.Size = new System.Drawing.Size(23, 18);
            this._label3.TabIndex = 12;
            this._label3.Text = "hr";
            // 
            // _label2
            // 
            this._label2.AutoSize = true;
            this._label2.Location = new System.Drawing.Point(100, 38);
            this._label2.Name = "_label2";
            this._label2.Size = new System.Drawing.Size(15, 18);
            this._label2.TabIndex = 11;
            this._label2.Text = ":";
            // 
            // _label1
            // 
            this._label1.AutoSize = true;
            this._label1.Location = new System.Drawing.Point(48, 38);
            this._label1.Name = "_label1";
            this._label1.Size = new System.Drawing.Size(15, 18);
            this._label1.TabIndex = 10;
            this._label1.Text = ":";
            // 
            // _secBox
            // 
            this._secBox.Location = new System.Drawing.Point(125, 35);
            this._secBox.Name = "_secBox";
            this._secBox.Size = new System.Drawing.Size(25, 26);
            this._secBox.TabIndex = 9;
            this._secBox.Text = "0";
            // 
            // _minBox
            // 
            this._minBox.Location = new System.Drawing.Point(69, 35);
            this._minBox.Name = "_minBox";
            this._minBox.Size = new System.Drawing.Size(25, 26);
            this._minBox.TabIndex = 8;
            this._minBox.Text = "0";
            // 
            // _hrsBox
            // 
            this._hrsBox.Location = new System.Drawing.Point(17, 35);
            this._hrsBox.Name = "_hrsBox";
            this._hrsBox.Size = new System.Drawing.Size(25, 26);
            this._hrsBox.TabIndex = 7;
            this._hrsBox.Text = "0";
            // 
            // _buttonStart
            // 
            this._buttonStart.BackColor = System.Drawing.SystemColors.Control;
            this._buttonStart.Location = new System.Drawing.Point(17, 150);
            this._buttonStart.Name = "_buttonStart";
            this._buttonStart.Size = new System.Drawing.Size(110, 26);
            this._buttonStart.TabIndex = 6;
            this._buttonStart.Text = "&Start Data Aqcuisition";
            this._buttonStart.UseVisualStyleBackColor = false;
            this._buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // _tiChart
            // 
            this._tiChart.BackColor = System.Drawing.Color.Chartreuse;
            this._tiChart.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this._tiChart.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(64)))), ((int)(((byte)(1)))));
            this._tiChart.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            this._tiChart.BorderlineWidth = 2;
            this._tiChart.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.Emboss;
            chartArea3.Area3DStyle.Inclination = 15;
            chartArea3.Area3DStyle.IsClustered = true;
            chartArea3.Area3DStyle.IsRightAngleAxes = false;
            chartArea3.Area3DStyle.Perspective = 10;
            chartArea3.Area3DStyle.Rotation = 10;
            chartArea3.Area3DStyle.WallWidth = 0;
            chartArea3.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.True;
            chartArea3.AxisX.IsLabelAutoFit = false;
            chartArea3.AxisX.IsStartedFromZero = false;
            chartArea3.AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea3.AxisX.LabelStyle.Format = "#.##";
            chartArea3.AxisX.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea3.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea3.AxisX.Title = "seconds (s)";
            chartArea3.AxisY.IsLabelAutoFit = false;
            chartArea3.AxisY.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea3.AxisY.LabelStyle.Format = "#.##";
            chartArea3.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea3.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea3.AxisY.Title = "Impedance (Ω)";
            chartArea3.BackColor = System.Drawing.Color.OldLace;
            chartArea3.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea3.BackSecondaryColor = System.Drawing.Color.White;
            chartArea3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea3.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea3.CursorX.Interval = 0.02D;
            chartArea3.CursorX.IsUserEnabled = true;
            chartArea3.CursorX.IsUserSelectionEnabled = true;
            chartArea3.CursorY.Interval = 0.02D;
            chartArea3.CursorY.IsUserEnabled = true;
            chartArea3.CursorY.IsUserSelectionEnabled = true;
            chartArea3.Name = "Default";
            chartArea3.ShadowColor = System.Drawing.Color.Transparent;
            this._tiChart.ChartAreas.Add(chartArea3);
            legend3.BackColor = System.Drawing.Color.Transparent;
            legend3.Enabled = false;
            legend3.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            legend3.IsTextAutoFit = false;
            legend3.Name = "Default";
            this._tiChart.Legends.Add(legend3);
            this._tiChart.Location = new System.Drawing.Point(247, 540);
            this._tiChart.Name = "_tiChart";
            series3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            series3.ChartArea = "Default";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Default";
            series3.Name = "Default";
            this._tiChart.Series.Add(series3);
            this._tiChart.Size = new System.Drawing.Size(1018, 248);
            this._tiChart.TabIndex = 29;
            title3.Name = "TI";
            title3.Text = "Transthoracic Impedence (TI)";
            this._tiChart.Titles.Add(title3);
            this._tiChart.CursorPositionChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.CursorEventArgs>(this.Zoom);
            this._tiChart.AxisViewChanged += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ViewEventArgs>(this.ResetInterval);
            // 
            // _timer1
            // 
            this._timer1.Interval = 1000;
            this._timer1.Tick += new System.EventHandler(this.clock_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 298);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 18);
            this.label1.TabIndex = 30;
            this.label1.Text = "Min";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 18);
            this.label2.TabIndex = 31;
            this.label2.Text = "Max";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 361);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 18);
            this.label3.TabIndex = 32;
            this.label3.Text = "Mean";
            // 
            // _refreshTimer
            // 
            this._refreshTimer.Interval = 40;
            this._refreshTimer.Tick += new System.EventHandler(this.refreshTimer_Tick);
            // 
            // _connectionCheck
            // 
            this._connectionCheck.Interval = 1000;
            this._connectionCheck.Tick += new System.EventHandler(this.ConnectionTimer_tick);
            // 
            // AppliedFilterView
            // 
            this.AppliedFilterView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AppliedFilterView.Location = new System.Drawing.Point(12, 497);
            this.AppliedFilterView.Name = "AppliedFilterView";
            treeNode1.Name = "DigitalFilterTypeNode";
            treeNode1.Text = "Type: None";
            treeNode2.Name = "DigitalFilterFrequencyNode";
            treeNode2.Text = "Freq: None";
            treeNode3.Name = "DigitalFilterNode";
            treeNode3.Text = "Digital Filter:";
            treeNode4.Name = "ECGMovingAverageNode";
            treeNode4.Text = "Moving Average: Off";
            treeNode5.Name = "Node1";
            treeNode5.Text = "ECG Filtering";
            treeNode6.Name = "TIMovingAverageNode";
            treeNode6.Text = "Moving Average: Off";
            treeNode7.Name = "Node2";
            treeNode7.Text = "TI Filtering";
            treeNode8.Name = "FilterTreeRoot";
            treeNode8.Text = "Applied Filters";
            this.AppliedFilterView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode8});
            this.AppliedFilterView.Size = new System.Drawing.Size(229, 176);
            this.AppliedFilterView.TabIndex = 37;
            // 
            // RealTimeData
            // 
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1277, 791);
            this.Controls.Add(this.AppliedFilterView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._tiChart);
            this.Controls.Add(this._groupBox1);
            this.Controls.Add(this._toolStrip1);
            this.Controls.Add(this._menuStrip2);
            this.Controls.Add(this._derivedChart);
            this.Controls.Add(this._ecgChart);
            this.Font = new System.Drawing.Font("Verdana", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "RealTimeData";
            this.Text = "Electrocardiogram-Derived Respiration Laboratory System";
            ((System.ComponentModel.ISupportInitialize)(this._derivedChart)).EndInit();
            this._menuStrip2.ResumeLayout(false);
            this._menuStrip2.PerformLayout();
            this._toolStrip1.ResumeLayout(false);
            this._toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._ecgChart)).EndInit();
            this._groupBox1.ResumeLayout(false);
            this._groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._tiChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion //Componenet Designer generated code

		#region timer
	    private void refreshTimer_Tick(object sender, EventArgs e)
	    {
            AddECGPoints();
            AddTIPoints();
	    }

	    private void AddTIPoints()
	    {
            var tiPtSeries = _tiChart.Series[0];
            _tiChart.Series.SuspendUpdates();
            var count = _tiStream.Count;
            if (count <= 0) return;
            while (count > 0)
            {
                tiPtSeries.Points.Add(_tiStream.Dequeue());
                count--;
            }

            ResizeTiPlotArea(tiPtSeries);
            _tiChart.Refresh();
	    }
	    
        private void AddECGPoints()
	    {
            var ecgPtSeries = _ecgChart.Series[0];
            _ecgChart.Series.SuspendUpdates();
            var count = _ecgStream.Count;
            if (count <= 0) return;
            while (count > 0)
            {
                ecgPtSeries.Points.Add(_ecgStream.Dequeue());
                count--;
            }
            ResizeEcgPlotArea(ecgPtSeries);
            _ecgChart.Refresh();
	    }

	    private void ResizeEcgPlotArea(Series ecgPtSeries)
	    {
            var lastPt = ecgPtSeries.Points[ecgPtSeries.Points.Count - 1];
            //ToDo - Replace 7500 with frequency * default display time
	        if (ecgPtSeries.Points.Count <= 500*15) return;
	        _ecgChart.ChartAreas[0].AxisX.Minimum = (int)lastPt.XValue - 14;
            _ecgChart.ChartAreas[0].AxisX.Maximum = (int)lastPt.XValue + 1;
	    }

	    private void ResizeTiPlotArea(Series tiPtSeries)
	    {
	        var lastPt = tiPtSeries.Points[tiPtSeries.Points.Count - 1];
            //ToDo - Replace 7500 with frequency * default display time
	        if (tiPtSeries.Points.Count <= 100*15) return;
            _tiChart.ChartAreas[0].AxisX.Minimum = (int)lastPt.XValue - 14;
            _tiChart.ChartAreas[0].AxisX.Maximum = (int)lastPt.XValue + 1;
	    }
		#endregion //timer

		#region click_actions

		#region timer control click_actions
        #region New Workflow
        private void Start_Click()
        {
            if (_timer1.Enabled)
            {
                //still running
                _timer1.Enabled = false;
                _refreshTimer.Enabled = false;
                _buttonStart.Text = @"&Start Data Aqcuisition";
                EnableTimerBoxes();
                FinishDataAqcuisition();
                DeriveTIFromECG();
                SetRawData();
            }
            else
            {
                //not running yet
                _buttonStart.Text = @"&Stop Data Aqcuisition";
                ResetAllCharts();
                UndoZoom();
                ResetFilters();
                ResetRawData();
                DisableTimerBoxes();
                _timer1.Enabled = true;
                StartDataAqcusition();
                _refreshTimer.Enabled = true;
            }
        }
	    private void FinishDataAqcuisition()
	    {
	        AddECGPoints();
            AddTIPoints();
	    }
	    private void StartDataAqcusition()
	    {
	        _state = new CancellationTokenSource();
	        _ecgStream = new Queue<DataPoint>();
	        _tiStream = new Queue<DataPoint>();
	        var producer = new DataAcquisition();
	        Task.Run(() => producer.Produce(_state.Token, _port), _state.Token);
	        Task.Run(() => DataTranslator.ProcessData(producer.DataQueue, _ecgStream, _tiStream, _state.Token),
	            _state.Token);
	    }
	    private void ResetRawData()
	    {
	        _rawEcg = new List<DataPoint>();
            _rawTI = new List<DataPoint>();
	    }
	    private void EnableTimerBoxes()
	    {
            _minBox.Enabled = true;
            _secBox.Enabled = true;
            _hrsBox.Enabled = true;
	    }
	    private void DisableTimerBoxes()
	    {
            _minBox.Enabled = false;
            _secBox.Enabled = false;
            _hrsBox.Enabled = false;

            if (!int.TryParse(_minBox.Text, out _min) || !int.TryParse(_secBox.Text, out _sec) ||
                !int.TryParse(_hrsBox.Text, out _hrs)) throw new ApplicationException("There was an error parsing the timer");
            if (_sec > 59)
            {
                _min += _sec / 60;
                _sec = _sec % 60;
            }
            if (_min > 59)
            {
                _hrs += _min / 60;
                _min = _min % 60;
            }
            if (_hrs == 0 && _min == 0 && _sec < 5) _sec = 5;
	    }
	    private void SetRawData()
	    {
            foreach (var p in _ecgChart.Series[0].Points)
            {
                _rawEcg.Add(new DataPoint(p.XValue, p.YValues[0]));
            }
            foreach (var p in _tiChart.Series[0].Points)
            {
                _rawTI.Add(new DataPoint(p.XValue, p.YValues[0]));
            }
	    }
        #endregion 
		private void buttonStart_Click(object sender, EventArgs e)
		{
		    if (!ButtonStartTimerHelper()) return;
		    //ResetFilterCheck();
		    ButtonStartRealTimeDataHelper();
		    StartDataAqcusition1();
		}

		private bool ButtonStartTimerHelper()
		{
			if (_timer1.Enabled)
			{
				_minBox.Enabled = true;
				_secBox.Enabled = true;
				_hrsBox.Enabled = true;
				_timer1.Enabled = false;
			    SetRawData();

				return true;
			}
		    //disable the text boxes
		    _minBox.Enabled = false;
		    _secBox.Enabled = false;
		    _hrsBox.Enabled = false;
		    _rawEcg = new List<DataPoint>();
		    _ecgChart.Annotations.Clear();
		    if (!int.TryParse(_minBox.Text, out _min) || !int.TryParse(_secBox.Text, out _sec) ||
		        !int.TryParse(_hrsBox.Text, out _hrs)) throw new ApplicationException("There was an error parsing the timer");
		    if (_sec > 59)
		    {
		        _min += _sec / 60;
		        _sec = _sec % 60;
		    }
		    if (_min > 59)
		    {
		        _hrs += _min / 60;
		        _min = _min % 60;
		    }
		    if (_hrs == 0 && _min == 0 && _sec < 5) _sec = 5;
		    _timer1.Enabled = true;
		    return true;
		}

		private void clock_Tick(Object sender, EventArgs e)
		{
			if (_sec <= 1)
			{
				if (_min == 0)
				{
					if (_hrs == 0)
					{
						_secLabel.Text = @"00";
					    buttonStart_Click(null, null);
                        _state.Cancel();
                        _peaks = PeakFinderImpl.FindPeaks(_ecgChart.Series[0].Points.ToList(),
                            _ecgChart.Series[0].Points.Select(dataPoint => dataPoint.YValues[0]).Concat(new[] { 0.0 }).Max() * .55,
                            0.0);
						return;
					}
					_hrs = _hrs - 1;
					_min = 59;
					_sec = 60;
				}
				else
				{
					_min = _min - 1;
					_sec = 60;
				}
			}
			_sec = _sec - 1;
			_minLabel.Text = _min.ToString(CultureInfo.InvariantCulture).Length > 1 ? _min.ToString(CultureInfo.InvariantCulture) : "0" + _min;
			_secLabel.Text = _sec.ToString(CultureInfo.InvariantCulture).Length > 1 ? _sec.ToString(CultureInfo.InvariantCulture) : "0" + _sec;
			_hrsLabel.Text = _hrs.ToString(CultureInfo.InvariantCulture).Length > 1 ? _hrs.ToString(CultureInfo.InvariantCulture) : "0" + _hrs;
		}

		private void ButtonStartRealTimeDataHelper()
		{
			if(IsSystemCollectingData())
			{
			    _refreshTimer.Enabled = false;
                MessageBox.Show(@"The variation in the R-R interval was too small to derive respiration", @"Load Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                _buttonStart.Text = @"&Start Data Aqcuisition";
			}
			else
			{
			    _refreshTimer.Enabled = true;
                _buttonStart.Text = @"&Stop Data Aqcuisition";
			}
		}

	    private Queue<DataPoint> _ecgStream;
	    private Queue<DataPoint> _tiStream; 
	    private CancellationTokenSource _state;

		private void StartDataAqcusition1()
		{
			if (_running)
			{
                _running = false;
			}
			else if (!_running)
			{
                StartRealTimeSample();
                _state = new CancellationTokenSource();
                _ecgStream = new Queue<DataPoint>();
                _tiStream = new Queue<DataPoint>();
                var producer = new DataAcquisition();
                Task.Run(() => producer.Produce(_state.Token, _port), _state.Token);
                Task.Run(() => DataTranslator.ProcessData(producer.DataQueue, _ecgStream, _tiStream, _state.Token), _state.Token);
                _running = true;
			}
		}
		#endregion //timer control click_actions

		#region file menu click_actions
		private void saveToolStripButton_Click_1(object sender, EventArgs e)
		{
		    if(IsSystemCollectingData())
		    {
		        MessageBox.Show(@"The system is unable to save data while it is still running", @"Save Error",
		            MessageBoxButtons.OK, MessageBoxIcon.Error);
		        return;
		    }
			Type officeType = Type.GetTypeFromProgID("Excel.Application");
			if (officeType == null)
			{
				MessageBox.Show(@"Microsoft Excel is required for saving to excel, defaulting to .txt");
			}
			else
			{
				var saveFile = new SaveFileDialog {FileName = "RawEKGData"};
			    if (saveFile.ShowDialog() == DialogResult.OK)
				{
					SaveData(saveFile.FileName);
				}
			}
		}

		private void SaveData(string fileName)
		{
			var xlApp = new Excel.Application {Visible = true};

		    var wb = xlApp.Workbooks.Add(System.Reflection.Missing.Value);
			Excel.Worksheet ws = wb.Worksheets[1];

			if (ws == null)
			{
				Console.WriteLine(@"Worksheet could not be created. Check that your office installation and project references are correct.");
			}

		    if (ws != null)
		    {
		        ws.Name = "ECG";
                var row = 1;
                const int yColumn = 1;

		        foreach (var pt in _rawEcg)
		        {
		            ws.Cells[row, yColumn] = pt.YValues;
		            row++;
		        }

		        ws = ws.Next;
		        ws.Name = "TI";
                row = 1;

		        foreach (var pt in _rawTI)
		        {
                    ws.Cells[row, yColumn] = pt.YValues;
                    row++;
		        }

		        wb.SaveAs(fileName,
		            Excel.XlFileFormat.xlWorkbookNormal,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            Excel.XlSaveAsAccessMode.xlExclusive,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value);

		        wb.Close(true,
		            System.Reflection.Missing.Value,
		            System.Reflection.Missing.Value);

		        xlApp.Quit();
		        Marshal.ReleaseComObject(ws);
		    }
		    Marshal.ReleaseComObject(wb);
			Marshal.ReleaseComObject(xlApp);
		}

		private void loadToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MessageBox.Show(@"To be implemented at a future time");
		}

		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Close();
		}

		private static void ResetToRaw(Chart chart, IEnumerable<DataPoint> rawData)
		{	
            ResetChart(chart);
		    foreach (var pt in rawData)
		    {
		        chart.Series["Default"].Points.Add(new DataPoint(pt.XValue, pt.YValues[0]));
		    }
		}

	    private static void ResetChart(Chart chart)
	    {
            chart.Series.Clear();

            chart.ChartAreas[0].AxisX.Minimum = 0;
            chart.ChartAreas[0].AxisX.Maximum = 15;
            var newSeries = new Series("Default")
            {
                ChartType = SeriesChartType.Spline,
                BorderWidth = 1,
                Color = Color.FromArgb(224, 64, 10),
                ShadowOffset = 1,
            };

            chart.Series.Add(newSeries);
            RedrawChart(chart);
	    }

	    private void ResetAllCharts()
	    {
	        ResetChart(_ecgChart);
            ResetChart(_tiChart);
	        ResetChart(_derivedChart);
	    }

		private void FilterECG()
		{
            if(_filterType == null) throw new Exception("An unexpected exception occurred during filtering");
			var filter = new ButterWorth(4, 500, _cornerFrequency, (ButterWorth.Type) _filterType);
            ResetChart(_ecgChart);
            _ecgChart.ChartAreas.SuspendUpdates();
			foreach (var pt in _rawEcg)
			{
			    _ecgChart.Series["Default"].Points.Add(new DataPoint(pt.XValue, filter.FilterValue(pt.YValues[0])));
			}
		    if (_annotate)
		    {
                _ecgChart.Annotations.Clear();
		        LabelPeaks();
		    }
			RedrawChart(_ecgChart);

		}

		private void documentationToolStripMenuItem_Click(object sender, EventArgs e)
		{
            //TODO-Change the path for a real executable
		    var path = Path.GetDirectoryName(
		        System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            if (Debugger.IsAttached)
                path = Path.GetFullPath(@"..\..\..");
		    path += @"\UserManual.docx";
            Process.Start(path);
		}
		#endregion //file menu click_actions

		#region toolbar click_actions
        //TODO-Readd these to the toolbar
		#endregion //toolbar click_actions

		#endregion //click_actions

		#region chart3 logic
		private void StartRealTimeSample()
		{

			// Reset number of series in the chart.
			_ecgChart.Series.Clear();
            _tiChart.Series.Clear();
            _derivedChart.Series.Clear();

            //reset the raw data holders
            _rawEcg.Clear();
            _rawTI.Clear();

            _ecgChart.ChartAreas[0].AxisX.Minimum = 0;
            _ecgChart.ChartAreas[0].AxisX.Maximum = 15;
			var newECGSeries = new Series("Default")
			{
				ChartType = SeriesChartType.Line,
				BorderWidth = 1,
				Color = Color.FromArgb(224, 64, 10),
				ShadowOffset = 1,
			};

            _tiChart.ChartAreas[0].AxisX.Minimum = 0;
            _tiChart.ChartAreas[0].AxisX.Maximum = 15;
            var newTISeries = new Series("Default")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 1,
                Color = Color.FromArgb(224, 64, 10),
                ShadowOffset = 1,
            };

            _derivedChart.ChartAreas[0].AxisX.Minimum = 0;
            _derivedChart.ChartAreas[0].AxisX.Maximum = 15;
            var newDerivedSeries = new Series("Default")
            {
                ChartType = SeriesChartType.Spline,
                BorderWidth = 1,
                Color = Color.FromArgb(224, 64, 10),
                ShadowOffset = 1,
            };

			_ecgChart.Series.Add(newECGSeries);
		    _tiChart.Series.Add(newTISeries);
		    _derivedChart.Series.Add(newDerivedSeries);
		}

	    private void ResetDerivedChart()
	    {
            _derivedChart.Series.Clear();

            _derivedChart.ChartAreas[0].AxisX.Minimum = 0;
            _derivedChart.ChartAreas[0].AxisX.Maximum = 15;
            var newDerivedSeries = new Series("Default")
            {
                ChartType = SeriesChartType.Spline,
                BorderWidth = 1,
                Color = Color.FromArgb(224, 64, 10),
                ShadowOffset = 1,
            };

            _derivedChart.Series.Add(newDerivedSeries);
	    }

		private void LabelPeaks_Click(object sender, EventArgs e)
		{
		    if (_annotate)
		    {
		        _ecgChart.Annotations.Clear();
		        _annotate = false;
		    }
		    else
		    {
                LabelPeaks();
		        _annotate = true;
		    }
		}

	    private void LabelPeaks()
	    {
            _peaks = PeakFinderImpl.FindPeaks(_ecgChart.Series[0].Points.ToList(), 
                _ecgChart.Series[0].Points.Select(dataPoint => dataPoint.YValues[0]).Concat(new[] {0.0}).Max()* .55, 
                0.0);
            foreach (var p in _peaks)
            {
                foreach (var dataPoint in _ecgChart.Series[0].Points)
                {
                    if (dataPoint.YValues[0] != p.YValues[0] || dataPoint.XValue != p.XValue) continue;
                    var annotation = new TextAnnotation
                    {
                        Text = string.Format("({0},{1})", dataPoint.YValues[0].ToString("f3"),
                            dataPoint.XValue.ToString("f3")),
                        AxisX = _ecgChart.ChartAreas[0].AxisX,
                        AxisY = _ecgChart.ChartAreas[0].AxisY,
                        AnchorX = dataPoint.XValue,
                        AnchorY = dataPoint.YValues[0]
                    };
                    _ecgChart.Annotations.Add(annotation);
                    _ecgChart.Update();
                }
            }
	    }
		#endregion // chart3 logic

        #region Zoom
        private static void ResetBorderLineWidth(Chart chart)
	    {
	        chart.BorderlineWidth = 2;
	    }

	    private void ResetBorderLineWidth()
	    {
	        ResetBorderLineWidth(_ecgChart);
            ResetBorderLineWidth(_tiChart);
            ResetBorderLineWidth(_derivedChart);
	    }

        private void Zoom(object sender, EventArgs e)
        {
            var chart = (Chart) sender;
            if (_running || chart.Series[0].Points.Count == 0) return;
            double min, max, mean;
            MinMaxMeanUsingScaleView(out min, out max, out mean, chart.Series[0].Points, _ecgChart.ChartAreas["Default"]);
            _meanTextBox.Text = string.Format("{0:F2}", mean);
            _maxTextBox.Text = string.Format("{0:F2}", max);
            _minTextBox.Text = string.Format("{0:F2}", min);
            ResetBorderLineWidth();
            chart.BorderlineColor = Color.Red;
            chart.BorderlineWidth = 10;
        }

	    private void ResetInterval(object sender, EventArgs e)
	    {
            var chart = ((Chart)sender).ChartAreas["Default"];
            var xStart = chart.AxisX.ScaleView.ViewMinimum;
            var xEnd = chart.AxisX.ScaleView.ViewMaximum;
            var yMin = chart.AxisY.ScaleView.ViewMinimum;
            var yMax = chart.AxisY.ScaleView.ViewMaximum;
	        chart.AxisY.Interval = (yMax - yMin)/5.0;
	        chart.AxisX.Interval = (xEnd - xStart)/5.0;
	    }

        private void UndoZoom()
        {
            ResetBorderLineWidth();
            if(_meanTextBox != null)
                _meanTextBox.Text = string.Format("");
            if(_maxTextBox != null)
                _maxTextBox.Text = string.Format("");
            if(_minTextBox != null)
                _minTextBox.Text = string.Format("");
        }

	    private void MinMaxMeanUsingScaleView(out double min, out double max, out double mean, 
            IEnumerable<DataPoint> dataPoints, ChartArea chart)
	    {
	        var xStart = chart.AxisX.ScaleView.ViewMinimum;
            var xEnd = chart.AxisX.ScaleView.ViewMaximum;
	        var yMin = chart.AxisY.ScaleView.ViewMinimum;
	        var yMax = chart.AxisY.ScaleView.ViewMaximum;
	        var count = 0;
	        min = 100.0;
	        max = -min;
	        mean = 0.0;
            foreach (var dataPoint in dataPoints)
            {
                if (dataPoint.XValue < xStart || dataPoint.YValues[0] < yMin || dataPoint.YValues[0] > yMax) continue;
                if (dataPoint.XValue > xEnd) break;
                count++;
                min = dataPoint.YValues[0] < min ? dataPoint.YValues[0] : min;
                max = dataPoint.YValues[0] > max ? dataPoint.YValues[0] : max;
                mean += dataPoint.YValues[0];
            }
	        mean = mean/count;
	    }

        #endregion

        #region Arduino Interface

        private bool _connection;
	    private string _port;

	    private void ConnectionTimer_tick(object sender, EventArgs e)
	    {
	        if (_connection) return;
	        Task.Run(() => DetectConnection());
	    }

	    private void DetectConnection()
	    {
	        foreach (var port in SerialPort.GetPortNames())
	        {
                var currentPort = new SerialPort(port, 57600);
	            try
	            {
	                currentPort.Open();
	                if (!DetectArduino(currentPort))
	                {
	                    currentPort.Close();
	                    continue;
	                }
	                _port = port;
                    currentPort.Close();
	                break;

	            }
	            catch (Exception)
	            {
	                currentPort.Close();
	            }
	        }
	    }

	    private bool DetectArduino(SerialPort port)
	    {
	        try
	        {
	            byte[] output = {100};
	            port.Write(output, 0, output.Count());
	            Thread.Sleep(100);
	            var word = "";
	            while (port.BytesToRead != 0)
	            {
	                word += Convert.ToChar(port.ReadChar());
	            }
	            if (word == "Connected")
	                _connection = true;
	            return _connection;
	        }
	        catch (Exception)
	        {
	            return _connection;
	        }
        }

        #endregion

	    private string _frequency = "";
	    private ButterWorth.Type? _filterType;
	    private string _ecgRunningAvg = "";
	    private string _tiRunningAvg = "";
	    private Boolean _ecgRunning;
	    private bool _tiRunning;
	    private int _cornerFrequency;

	    private void _filtersToolStripMenuItem_Click(object sender, EventArgs e)
	    {
	        if(IsSystemCollectingData())
	        {
	            MessageBox.Show(@"The System is unable to filter while collecting data", @"Filtering Error",
	                MessageBoxButtons.OK, MessageBoxIcon.Error);
	            return;
	        }
	        using (var form = new FilterOptionsView())
            {
                form.LoadForm(_frequency, _filterType, _ecgRunning, _ecgRunningAvg, _tiRunning, _tiRunningAvg);
                form.ShowDialog();
                if (form.DialogResult == DialogResult.OK)
                {
                    if (AreECGFiltersChanged(form))
                    {
                        ResetToRaw(_ecgChart, _rawEcg);
                        RedrawChart(_ecgChart);
                    }
                    if (AreTIFiltersChanged(form))
                    {
                        ResetToRaw(_tiChart, _rawTI);
                        RedrawChart(_tiChart);
                    }
                    _frequency = form.Frequency;
                    _filterType = form.FilterType;
                    _ecgRunning = form.EcgMovingAvgEnable;
                    _ecgRunningAvg = form.ECGMovingAverage;
                    _tiRunning = form.TiMovingAvgEnable;
                    _tiRunningAvg = form.TIMovingAverage;
                    UpdateFilterTree();
                }
            }

            if(_tiRunning || _ecgRunning)
                ApplyMovingAverage();
	        if (_filterType != null)
	        {
	            _cornerFrequency = int.Parse(_frequency.Split(null)[0]);
	            FilterECG();
	        }
            DeriveTIFromECG();
        }

	    private void ResetFilters()
	    {
	        _frequency = "";
	        _filterType = null;
	        _ecgRunning = false;
	        _ecgRunningAvg = "";
	        _tiRunning = false;
	        _tiRunningAvg = "";
            UpdateFilterTree();
	    }

	    private bool AreTIFiltersChanged(FilterOptionsView form)
	    {
	        if (_tiRunning != form.TiMovingAvgEnable)
	            return true;
	        return _tiRunningAvg != form.TIMovingAverage;
	    }

        private bool AreECGFiltersChanged(FilterOptionsView form)
        {
            if (_filterType != form.FilterType)
                return true;
            if (_ecgRunning != form.EcgMovingAvgEnable)
                return true;
            if (_ecgRunningAvg != form.ECGMovingAverage)
                return true;
            return _frequency != form.Frequency;
        }

	    private void UpdateFilterTree()
	    {
	        foreach (TreeNode node in AppliedFilterView.Nodes[0].Nodes)
	        {
	            foreach (TreeNode n in node.Nodes)
	            {
	                UpdateFilterTree(n);
	            }
	        }

            AppliedFilterView.Nodes[0].ExpandAll();
	    }

	    private void UpdateFilterTree(TreeNode node)
	    {
	        switch (node.Name)
	        {
	            case "TIMovingAverageNode":
	                node.Text = _tiRunning ? @"Moving Average: On" : @"Moving Average: Off";
	                break;
	            case "ECGMovingAverageNode":
	                node.Text = _ecgRunning ? @"Moving Average: On" : @"Moving Average: Off";
	                break;
	            case "DigitalFilterNode":
	                var type = "Type: ";
	                var frequency = "Freq: ";
	                if (_filterType == null)
	                {
	                    type += "None";
	                    frequency += "None";
	                }
	                else
	                {
	                    type += _filterType;
	                    frequency += @"7-15 Hz";
	                }
	                node.Nodes["DigitalFilterTypeNode"].Text = type;
	                node.Nodes["DigitalFilterFrequencyNode"].Text = frequency;
	                break;
	        }
	    }

	    private void ApplyMovingAverage()
	    {
	        int i = 0;
	        if (!string.IsNullOrEmpty(_ecgRunningAvg))
	        {
	            if (_ecgChart.Series["Default"].Points.Count > 0)
	            {
	                var filter = new MovingAverageFilter(int.Parse(_ecgRunningAvg));
	                foreach (var pt in _ecgChart.Series[0].Points)
	                {
	                    if (i >= _rawEcg.Count) continue;
	                    var retVal = filter.Process(_rawEcg[i].YValues[0]);
	                    if (retVal == null) continue;
	                    pt.YValues[0] = retVal.Value;
	                    i++;
	                }
	                if (_annotate)
	                {
	                    _ecgChart.Annotations.Clear();
	                    LabelPeaks();
	                }
	                _ecgChart.Invalidate();
	            }
	            else
	            {
	                MessageBox.Show(@"A Moving Average can not be applied to a dataset with no data.", @"Filter Error",
	                    MessageBoxButtons.OK, MessageBoxIcon.Error);
	            }
	        }
	        if (!string.IsNullOrEmpty(_tiRunningAvg))
	        {
	            if (_tiChart.Series["Default"].Points.Count > 0)
	            {
	                var filter = new MovingAverageFilter(int.Parse(_tiRunningAvg));
	                foreach (var pt in _tiChart.Series[0].Points)
	                {
	                    if (i >= _rawTI.Count) continue;
	                    var retVal = filter.Process(_rawTI[i].YValues[0]);
	                    if (retVal == null) continue;
	                    pt.YValues[0] = retVal.Value;
	                    i++;
	                }
	                if (_annotate)
	                {
	                    _tiChart.Annotations.Clear();
	                }
	                _tiChart.Invalidate();
	            }
	            else
	            {
	                MessageBox.Show(@"A Moving Average can not be applied to a dataset with no data", @"Filter Error",
	                    MessageBoxButtons.OK, MessageBoxIcon.Error);
	            }
	        }

	    }

	    private bool IsSystemCollectingData()
	    {
	        return _refreshTimer.Enabled;
	    }

	    private const double ECGFrequency = 500;
	    private const double TIFrequency = 500;

	    private void ECGLoad_Click(object sender, EventArgs e)
	    {
            if(IsSystemCollectingData())
            {
                MessageBox.Show(@"The system is unable to load data while it is still running", @"Load Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var fileName = SelectFile();
            if (fileName == null) return;
            ResetAllCharts();
            ReadECGData(fileName);
            SetRawData();
        }

	    private void ReadECGData(string fileName)
	    {
            var data = ReadData(fileName, "ECG");
            if (data == null) return;
            var chart = _ecgChart;
            UndoZoom();
            SuspendUpdates(chart);
            LoadData(data, chart, "Default", ECGFrequency);
            RedrawChart(chart);
            CreateChartViewArea(chart);
            DeriveTIFromECG();
	    }

	    private void ReadTIData(string fileName)
	    {
            var data = ReadData(fileName, "TI");
            if (data == null) return;
            var chart = _tiChart;
            UndoZoom();
            SuspendUpdates(chart);
            LoadData(data, chart, "Default", TIFrequency);
            RedrawChart(chart);
            CreateChartViewArea(chart);
	    }

        private void TILoad_Click(object sender, EventArgs e)
        {
            if (IsSystemCollectingData())
            {
                MessageBox.Show(@"The system is unable to load data while it is still running", @"Load Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var fileName = SelectFile();
            if (fileName == null) return;
            ResetAllCharts();
            ReadTIData(fileName);
            SetRawData();
        }

        private void ECGTILoad_Click(object sender, EventArgs e)
        {
            if (IsSystemCollectingData())
            {
                MessageBox.Show(@"The system is unable to load data while it is still running", @"Load Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var fileName = SelectFile();
            if (fileName == null) return;

            ResetAllCharts();
            ReadTIData(fileName);
            ReadECGData(fileName);
            SetRawData();

        }

	    private void LoadData(IReadOnlyList<double> data, Chart chart, string seriesName, double frequency)
	    {
	        if (data == null) throw new ArgumentNullException("data");
	        var series = chart.Series[seriesName];
            for (var i = 0; i < data.Count; i++)
	        {
	            series.Points.Add(new DataPoint(i/frequency, data[i]));
	        }
	    }

	    private static string SelectFile()
	    {
            var openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = "c:\\",
                Filter = @"txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 2,
                RestoreDirectory = true
            };

            return openFileDialog1.ShowDialog() == DialogResult.OK ? openFileDialog1.FileName : null;
	    }

	    private static List<Double> ReadData(string fileName, string sheetName)
	    {
	        var dataPoints = new List<double>();
	        Excel.Application excel = null;
	        try
	        {

	            excel = new Excel.Application();
	            var sheet = excel.Workbooks.Open(fileName).Sheets[sheetName];
	            var i = 1;
	            while (true)
	            {
	                if (sheet.Range(string.Format("A{0}", i)).Value == null) break;
	                double val;
	                if (!double.TryParse(sheet.Range(string.Format("A{0}", i)).Value.ToString(), out val))
	                {
	                    MessageBox.Show(string.Format("The data in cell A{0} is not a recognizable number", i),
	                        @"Load Error",
	                        MessageBoxButtons.OK, MessageBoxIcon.Error);
	                    return null;
	                }
	                dataPoints.Add(val);
	                i++;
	            }
	        }
	        catch (Exception)
	        {
	            MessageBox.Show(@"An unknown error occurred while trying to load the data", @"Load Data Error",
	                MessageBoxButtons.OK, MessageBoxIcon.Error);
	        }
	        finally
	        {
	            if (excel != null) excel.Quit();
	        }
	        return dataPoints;
	    }

	    private void DeriveTIFromECG()
	    {
            ResetDerivedChart();
            var kurtosis = new Kurtosis(_rawEcg).Calculate();
            foreach (var p in kurtosis)
            {
                if (double.IsNaN(p.YValues[0]))
                {
                    //ToDo-Change to an actual error message
                    MessageBox.Show(@"The variation in the R-R interval was too small to derive respiration", @"R-R Interval Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                _derivedChart.Series["Default"].Points.Add(new DataPoint(p.XValue, p.YValues[0]));
            }

            if(_derivedChart.Series["Default"].Points.Count > 2)
                CreateChartViewArea(_derivedChart);
	    }

	    private void CreateChartViewArea(Chart chart)
	    {
	        var series = chart.Series["Default"];
	        var min = 0.0;
	        var max = 0.0;
	        foreach (var point in chart.Series["Default"].Points)
	        {
	            if (point.YValues[0] < min)
	                min = point.YValues[0];
	            if (point.YValues[0] > max)
	                max = point.YValues[0];
	        }

            chart.ChartAreas[0].AxisY.Minimum = (min*1.3);
            chart.ChartAreas[0].AxisY.Maximum = (max*1.3);
            var val = (int)(series.Points[series.Points.Count - 1].XValue+0.5) + 1.0;
            chart.ChartAreas[0].AxisX.Maximum = val;
            var val2 = val - 10.0;
            if (val2 < 0)
                val2 = 0.0;
            chart.ChartAreas[0].AxisX.ScaleView.Zoom(val2, val);
	        ResetInterval(chart, null);
	    }

        private static void SuspendUpdates(Chart chart)
        {
            chart.Series.SuspendUpdates();
        }

        private static void RefreshChart(Chart chart)
        {
            if (chart == null) throw new ArgumentNullException("chart");
            chart.Refresh();
        }

        private static void RedrawChart(Chart chart)
        {
            if (chart == null) throw new ArgumentNullException("chart");
            chart.Invalidate();
        }
    }
}
