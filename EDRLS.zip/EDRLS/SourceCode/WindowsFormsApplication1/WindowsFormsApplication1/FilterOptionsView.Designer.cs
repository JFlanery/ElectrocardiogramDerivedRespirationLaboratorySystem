﻿using System;
using System.Drawing;
using System.Globalization;
using System.Security.AccessControl;

namespace WindowsFormsApplication1
{
    partial class FilterOptionsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EcgGroupBox = new System.Windows.Forms.GroupBox();
            this.ECGMovingAvgEnableCheck = new System.Windows.Forms.CheckBox();
            this.BandPassFilterContainer = new System.Windows.Forms.GroupBox();
            this.BandPassFilter7To15 = new System.Windows.Forms.CheckBox();
            this.HighPassFilterContainer = new System.Windows.Forms.GroupBox();
            this.HighPassFilter20Hz = new System.Windows.Forms.CheckBox();
            this.HighPassFilter8Hz = new System.Windows.Forms.CheckBox();
            this.HighPassFilter5Hz = new System.Windows.Forms.CheckBox();
            this.LowPassFilterContainer = new System.Windows.Forms.GroupBox();
            this.LowPassFilter20Hz = new System.Windows.Forms.CheckBox();
            this.LowPassFilter8Hz = new System.Windows.Forms.CheckBox();
            this.LowPassFilter5Hz = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ECGTrackbar = new System.Windows.Forms.TrackBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TIMovingAvgEnableBox = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TITrackbar = new System.Windows.Forms.TrackBar();
            this.OkButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.filterResetButton = new System.Windows.Forms.Button();
            this.EcgGroupBox.SuspendLayout();
            this.BandPassFilterContainer.SuspendLayout();
            this.HighPassFilterContainer.SuspendLayout();
            this.LowPassFilterContainer.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ECGTrackbar)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TITrackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // EcgGroupBox
            // 
            this.EcgGroupBox.Controls.Add(this.ECGMovingAvgEnableCheck);
            this.EcgGroupBox.Controls.Add(this.BandPassFilterContainer);
            this.EcgGroupBox.Controls.Add(this.HighPassFilterContainer);
            this.EcgGroupBox.Controls.Add(this.LowPassFilterContainer);
            this.EcgGroupBox.Controls.Add(this.groupBox3);
            this.EcgGroupBox.Location = new System.Drawing.Point(12, 12);
            this.EcgGroupBox.Name = "EcgGroupBox";
            this.EcgGroupBox.Size = new System.Drawing.Size(567, 262);
            this.EcgGroupBox.TabIndex = 0;
            this.EcgGroupBox.TabStop = false;
            this.EcgGroupBox.Text = "ECG - Filtering";
            // 
            // ECGMovingAvgEnableCheck
            // 
            this.ECGMovingAvgEnableCheck.AutoSize = true;
            this.ECGMovingAvgEnableCheck.Location = new System.Drawing.Point(15, 129);
            this.ECGMovingAvgEnableCheck.Name = "ECGMovingAvgEnableCheck";
            this.ECGMovingAvgEnableCheck.Size = new System.Drawing.Size(180, 21);
            this.ECGMovingAvgEnableCheck.TabIndex = 6;
            this.ECGMovingAvgEnableCheck.Text = "Enable Moving Average";
            this.ECGMovingAvgEnableCheck.UseVisualStyleBackColor = true;
            this.ECGMovingAvgEnableCheck.CheckedChanged += new System.EventHandler(this.ECGMovingAvgEnable);
            // 
            // BandPassFilterContainer
            // 
            this.BandPassFilterContainer.Controls.Add(this.BandPassFilter7To15);
            this.BandPassFilterContainer.Location = new System.Drawing.Point(376, 21);
            this.BandPassFilterContainer.Name = "BandPassFilterContainer";
            this.BandPassFilterContainer.Size = new System.Drawing.Size(179, 110);
            this.BandPassFilterContainer.TabIndex = 5;
            this.BandPassFilterContainer.TabStop = false;
            this.BandPassFilterContainer.Text = "Band Pass Filter";
            // 
            // BandPassFilter7To15
            // 
            this.BandPassFilter7To15.AutoSize = true;
            this.BandPassFilter7To15.Location = new System.Drawing.Point(20, 50);
            this.BandPassFilter7To15.Name = "BandPassFilter7To15";
            this.BandPassFilter7To15.Size = new System.Drawing.Size(116, 21);
            this.BandPassFilter7To15.TabIndex = 1;
            this.BandPassFilter7To15.Text = "7 Hz to 15 Hz";
            this.BandPassFilter7To15.UseVisualStyleBackColor = true;
            this.BandPassFilter7To15.Click += new System.EventHandler(this.FilterChecked);
            // 
            // HighPassFilterContainer
            // 
            this.HighPassFilterContainer.Controls.Add(this.HighPassFilter20Hz);
            this.HighPassFilterContainer.Controls.Add(this.HighPassFilter8Hz);
            this.HighPassFilterContainer.Controls.Add(this.HighPassFilter5Hz);
            this.HighPassFilterContainer.Location = new System.Drawing.Point(189, 21);
            this.HighPassFilterContainer.Name = "HighPassFilterContainer";
            this.HighPassFilterContainer.Size = new System.Drawing.Size(181, 110);
            this.HighPassFilterContainer.TabIndex = 4;
            this.HighPassFilterContainer.TabStop = false;
            this.HighPassFilterContainer.Text = "High Pass Filter";
            // 
            // HighPassFilter20Hz
            // 
            this.HighPassFilter20Hz.AutoSize = true;
            this.HighPassFilter20Hz.Location = new System.Drawing.Point(26, 75);
            this.HighPassFilter20Hz.Name = "HighPassFilter20Hz";
            this.HighPassFilter20Hz.Size = new System.Drawing.Size(67, 21);
            this.HighPassFilter20Hz.TabIndex = 3;
            this.HighPassFilter20Hz.Text = "20 Hz";
            this.HighPassFilter20Hz.UseVisualStyleBackColor = true;
            this.HighPassFilter20Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // HighPassFilter8Hz
            // 
            this.HighPassFilter8Hz.AutoSize = true;
            this.HighPassFilter8Hz.Location = new System.Drawing.Point(26, 48);
            this.HighPassFilter8Hz.Name = "HighPassFilter8Hz";
            this.HighPassFilter8Hz.Size = new System.Drawing.Size(59, 21);
            this.HighPassFilter8Hz.TabIndex = 2;
            this.HighPassFilter8Hz.Text = "8 Hz";
            this.HighPassFilter8Hz.UseVisualStyleBackColor = true;
            this.HighPassFilter8Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // HighPassFilter5Hz
            // 
            this.HighPassFilter5Hz.AutoSize = true;
            this.HighPassFilter5Hz.Location = new System.Drawing.Point(26, 21);
            this.HighPassFilter5Hz.Name = "HighPassFilter5Hz";
            this.HighPassFilter5Hz.Size = new System.Drawing.Size(59, 21);
            this.HighPassFilter5Hz.TabIndex = 1;
            this.HighPassFilter5Hz.Text = "5 Hz";
            this.HighPassFilter5Hz.UseVisualStyleBackColor = true;
            this.HighPassFilter5Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // LowPassFilterContainer
            // 
            this.LowPassFilterContainer.Controls.Add(this.LowPassFilter20Hz);
            this.LowPassFilterContainer.Controls.Add(this.LowPassFilter8Hz);
            this.LowPassFilterContainer.Controls.Add(this.LowPassFilter5Hz);
            this.LowPassFilterContainer.Location = new System.Drawing.Point(0, 22);
            this.LowPassFilterContainer.Name = "LowPassFilterContainer";
            this.LowPassFilterContainer.Size = new System.Drawing.Size(183, 109);
            this.LowPassFilterContainer.TabIndex = 3;
            this.LowPassFilterContainer.TabStop = false;
            this.LowPassFilterContainer.Text = "Low Pass Filters";
            // 
            // LowPassFilter20Hz
            // 
            this.LowPassFilter20Hz.AutoSize = true;
            this.LowPassFilter20Hz.Location = new System.Drawing.Point(15, 76);
            this.LowPassFilter20Hz.Name = "LowPassFilter20Hz";
            this.LowPassFilter20Hz.Size = new System.Drawing.Size(67, 21);
            this.LowPassFilter20Hz.TabIndex = 2;
            this.LowPassFilter20Hz.Text = "20 Hz";
            this.LowPassFilter20Hz.UseVisualStyleBackColor = true;
            this.LowPassFilter20Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // LowPassFilter8Hz
            // 
            this.LowPassFilter8Hz.AutoSize = true;
            this.LowPassFilter8Hz.Location = new System.Drawing.Point(15, 49);
            this.LowPassFilter8Hz.Name = "LowPassFilter8Hz";
            this.LowPassFilter8Hz.Size = new System.Drawing.Size(59, 21);
            this.LowPassFilter8Hz.TabIndex = 1;
            this.LowPassFilter8Hz.Text = "8 Hz";
            this.LowPassFilter8Hz.UseVisualStyleBackColor = true;
            this.LowPassFilter8Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // LowPassFilter5Hz
            // 
            this.LowPassFilter5Hz.AutoSize = true;
            this.LowPassFilter5Hz.Location = new System.Drawing.Point(15, 22);
            this.LowPassFilter5Hz.Name = "LowPassFilter5Hz";
            this.LowPassFilter5Hz.Size = new System.Drawing.Size(59, 21);
            this.LowPassFilter5Hz.TabIndex = 0;
            this.LowPassFilter5Hz.Text = "5 Hz";
            this.LowPassFilter5Hz.UseVisualStyleBackColor = true;
            this.LowPassFilter5Hz.Click += new System.EventHandler(this.FilterChecked);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.ECGTrackbar);
            this.groupBox3.Location = new System.Drawing.Point(6, 156);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(555, 83);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Moving Average Filter";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(105, 42);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(29, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Window Size";
            // 
            // ECGTrackbar
            // 
            this.ECGTrackbar.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ECGTrackbar.Enabled = false;
            this.ECGTrackbar.Location = new System.Drawing.Point(150, 21);
            this.ECGTrackbar.Minimum = 2;
            this.ECGTrackbar.Name = "ECGTrackbar";
            this.ECGTrackbar.Size = new System.Drawing.Size(399, 56);
            this.ECGTrackbar.TabIndex = 1;
            this.ECGTrackbar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.ECGTrackbar.Value = 2;
            this.ECGTrackbar.ValueChanged += new System.EventHandler(this.ECGTrackbarTickChange);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TIMovingAvgEnableBox);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Location = new System.Drawing.Point(12, 282);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(567, 138);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TI - Filtering";
            // 
            // TIMovingAvgEnableBox
            // 
            this.TIMovingAvgEnableBox.AutoSize = true;
            this.TIMovingAvgEnableBox.Location = new System.Drawing.Point(15, 31);
            this.TIMovingAvgEnableBox.Name = "TIMovingAvgEnableBox";
            this.TIMovingAvgEnableBox.Size = new System.Drawing.Size(180, 21);
            this.TIMovingAvgEnableBox.TabIndex = 4;
            this.TIMovingAvgEnableBox.Text = "Enable Moving Average";
            this.TIMovingAvgEnableBox.UseVisualStyleBackColor = true;
            this.TIMovingAvgEnableBox.CheckedChanged += new System.EventHandler(this.TIMovingAvgEnable);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.TITrackbar);
            this.groupBox4.Location = new System.Drawing.Point(6, 58);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(555, 83);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Moving Average Filter";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(105, 42);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(29, 22);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Window Size";
            // 
            // TITrackbar
            // 
            this.TITrackbar.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TITrackbar.Enabled = false;
            this.TITrackbar.Location = new System.Drawing.Point(150, 21);
            this.TITrackbar.Minimum = 2;
            this.TITrackbar.Name = "TITrackbar";
            this.TITrackbar.Size = new System.Drawing.Size(399, 56);
            this.TITrackbar.TabIndex = 1;
            this.TITrackbar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.TITrackbar.Value = 2;
            this.TITrackbar.ValueChanged += new System.EventHandler(this.TITrackBarTickChanged);
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(146, 449);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(75, 37);
            this.OkButton.TabIndex = 2;
            this.OkButton.Text = "Okay";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.ok_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(253, 449);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 37);
            this.CancelButton.TabIndex = 3;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.cancel_Click);
            // 
            // filterResetButton
            // 
            this.filterResetButton.Location = new System.Drawing.Point(363, 449);
            this.filterResetButton.Name = "filterResetButton";
            this.filterResetButton.Size = new System.Drawing.Size(75, 37);
            this.filterResetButton.TabIndex = 4;
            this.filterResetButton.Text = "Reset";
            this.filterResetButton.UseVisualStyleBackColor = true;
            this.filterResetButton.Click += new System.EventHandler(this.filterResetButton_Click);
            // 
            // FilterOptionsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 498);
            this.Controls.Add(this.filterResetButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.EcgGroupBox);
            this.Name = "FilterOptionsView";
            this.Text = "Filter Options";
            this.EcgGroupBox.ResumeLayout(false);
            this.EcgGroupBox.PerformLayout();
            this.BandPassFilterContainer.ResumeLayout(false);
            this.BandPassFilterContainer.PerformLayout();
            this.HighPassFilterContainer.ResumeLayout(false);
            this.HighPassFilterContainer.PerformLayout();
            this.LowPassFilterContainer.ResumeLayout(false);
            this.LowPassFilterContainer.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ECGTrackbar)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TITrackbar)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.GroupBox EcgGroupBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TrackBar ECGTrackbar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar TITrackbar;
        private System.Windows.Forms.GroupBox BandPassFilterContainer;
        private System.Windows.Forms.GroupBox HighPassFilterContainer;
        private System.Windows.Forms.GroupBox LowPassFilterContainer;
        private System.Windows.Forms.CheckBox BandPassFilter7To15;
        private System.Windows.Forms.CheckBox HighPassFilter20Hz;
        private System.Windows.Forms.CheckBox HighPassFilter8Hz;
        private System.Windows.Forms.CheckBox HighPassFilter5Hz;
        private System.Windows.Forms.CheckBox LowPassFilter20Hz;
        private System.Windows.Forms.CheckBox LowPassFilter8Hz;
        private System.Windows.Forms.CheckBox LowPassFilter5Hz;
        private System.Windows.Forms.CheckBox TIMovingAvgEnableBox;
        private System.Windows.Forms.CheckBox ECGMovingAvgEnableCheck;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button filterResetButton;
    }
}