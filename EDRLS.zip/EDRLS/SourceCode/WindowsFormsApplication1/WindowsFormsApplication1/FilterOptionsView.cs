﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using SL;

namespace WindowsFormsApplication1
{
    public partial class FilterOptionsView : Form
    {

        public string Frequency { get; private set;}
        public ButterWorth.Type? FilterType { get; private set;}
        public string ECGMovingAverage { get; private set; }
        public string TIMovingAverage { get; private set; }

        public bool TiMovingAvgEnable { 
            get { return TIMovingAvgEnableBox.Checked; }
            private set { TIMovingAvgEnableBox.Checked = value; }
        }

        public bool EcgMovingAvgEnable
        {
            get { return ECGMovingAvgEnableCheck.Checked; }
            private set { ECGMovingAvgEnableCheck.Checked = value; }
        }

        public FilterOptionsView()
        {
            TIMovingAverage = "";
            ECGMovingAverage = "";
            Frequency = "";
            InitializeComponent();
        }

        private void ECGMovingAvgEnable(Object sender, EventArgs e)
        {
            ECGTrackbar.Enabled = ECGMovingAvgEnableCheck.Checked;
            ECGMovingAverage = ECGTrackbar.Enabled ? textBox1.Text : "";
        }

        private void TIMovingAvgEnable(Object sender, EventArgs e)
        {
            TITrackbar.Enabled = TIMovingAvgEnableBox.Checked;
            TIMovingAverage = TITrackbar.Enabled ? textBox2.Text : "";
        }

        private void ECGTrackbarTickChange(object sender, EventArgs e)
        {
            textBox1.Text = ECGTrackbar.Value.ToString(CultureInfo.InvariantCulture);
            ECGMovingAverage = textBox1.Text;
        }

        private void TITrackBarTickChanged(object sender, EventArgs e)
        {
            textBox2.Text = TITrackbar.Value.ToString(CultureInfo.InvariantCulture);
            TIMovingAverage = textBox2.Text;
        }

        private void FilterChecked(object sender, EventArgs e)
        {
            if(sender.GetType() != typeof(CheckBox))
                throw new ArgumentException("Event Handler expects the type of sender to be a Radio Button");
            var sentObject = (CheckBox) sender;
            Frequency = "";
            FilterType = null;
            foreach (CheckBox c in LowPassFilterContainer.Controls)
            {
                if (c.Name == sentObject.Name && c.Checked)
                {
                    FilterType = ButterWorth.Type.LowPass;
                    Frequency = c.Text;
                }
                else
                    c.Checked = false;
            }
            foreach (CheckBox c in HighPassFilterContainer.Controls)
            {
                if (c.Name == sentObject.Name && c.Checked)
                {
                    FilterType = ButterWorth.Type.HighPass;
                    Frequency = c.Text;
                }
                else
                    c.Checked = false;
            }
            foreach (CheckBox c in BandPassFilterContainer.Controls)
            {
                if (c.Name == sentObject.Name && c.Checked)
                {
                    FilterType = ButterWorth.Type.BandPass;
                    Frequency = c.Text;
                }
                else
                    c.Checked = false;
            }
        }

        public void LoadForm(string frequency, ButterWorth.Type? filterType, bool ecgMovingAvgEnable, string ecgMovingAvg, bool tiMovingAvgEnable, string tiMovingAvg)
        {
	        switch (filterType)
	        {
	            case ButterWorth.Type.HighPass:
	                foreach (var button in HighPassFilterContainer.Controls.Cast<CheckBox>().Where(button => button.Text == frequency))
	                {
	                    button.Checked = true;
	                }
	                break;
                case ButterWorth.Type.LowPass:
                    foreach (var button in LowPassFilterContainer.Controls.Cast<CheckBox>().Where(button => button.Text == frequency))
                    {
                        button.Checked = true;
                    }
	                break;
                case ButterWorth.Type.BandPass:
                    foreach (var button in BandPassFilterContainer.Controls.Cast<CheckBox>().Where(button => button.Text == frequency))
                    {
                        button.Checked = true;
                    }
	                break;
	        }

            TiMovingAvgEnable = tiMovingAvgEnable;
            EcgMovingAvgEnable = ecgMovingAvgEnable;
            if (!string.IsNullOrEmpty(ecgMovingAvg))
            {
                ECGTrackbar.Value = int.Parse(ecgMovingAvg);
                textBox1.Text = ECGTrackbar.Value.ToString(CultureInfo.InvariantCulture);
            }
            if (string.IsNullOrEmpty(tiMovingAvg)) return;
            TITrackbar.Value = int.Parse(tiMovingAvg);
            textBox2.Text = TITrackbar.Value.ToString(CultureInfo.InvariantCulture);
        }

        public void FilterClear()
        {
            Frequency = "";
            FilterType = null;
            foreach (CheckBox c in LowPassFilterContainer.Controls)
            {
                c.Checked = false;
            }
            foreach (CheckBox c in HighPassFilterContainer.Controls)
            {
                c.Checked = false;
            }
            foreach (CheckBox c in BandPassFilterContainer.Controls)
            {
                c.Checked = false;
            } 
        }

        private void ok_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void filterResetButton_Click(object sender, EventArgs e)
        {
            FilterClear();
            EcgMovingAvgEnable = false;
            ECGMovingAverage = "";
            TiMovingAvgEnable = false;
            TIMovingAverage = "";
        }
    }
}
