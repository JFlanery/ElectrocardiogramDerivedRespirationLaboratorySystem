﻿using System;
using System.Collections.Concurrent;
using System.IO.Ports;
using System.Linq;
using System.Threading;

namespace DL
{
    public class DataAcquisition
    {
        private readonly byte[] _startAquisition = {200};
        private readonly byte[] _stopAquisition = {100};
        public ConcurrentQueue<Tuple<string, double, double>> DataQueue;

        public DataAcquisition()
        {
            DataQueue = new ConcurrentQueue<Tuple<string, double, double>>();
        }

        public void Produce(CancellationToken tkn, string portName)
        {
            var port = new SerialPort("COM5", 57600);
            port.Open();
            var count = 0.0;
            port.Write(_startAquisition, 0, _startAquisition.Count());
            Thread.Sleep(100);
            while (true)
            {
                try
                {
                    if (port.BytesToRead <= 1) continue;
                    var valueType = port.ReadLine().Trim();
                    double value;

                    if (tkn.IsCancellationRequested)
                    {
                        port.BreakState = true;
                        valueType = port.ReadLine().Trim();
                        if (double.TryParse(port.ReadLine(), out value))
                        {
                            DataQueue.Enqueue(Tuple.Create(valueType, ++count, value));
                        }
                        if (port.BytesToRead == 0)
                        {
                            tkn.ThrowIfCancellationRequested();
                            port.DiscardInBuffer();
                        }
                    }

                    if (double.TryParse(port.ReadLine(), out value))
                    {
                        DataQueue.Enqueue(Tuple.Create(valueType, ++count, value));
                    }

                }
                catch (Exception)
                {
                    if (port.IsOpen)
                        port.Close();
                }
            }

        }
    }
}
