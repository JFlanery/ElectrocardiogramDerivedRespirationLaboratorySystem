﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;

namespace DL
{
    public class DataTranslator
    {
        public static void ProcessData(ConcurrentQueue<Tuple<string, double,double>> dataQueue, Queue<DataPoint> ecgHolder, Queue<DataPoint> tiHolder, CancellationToken tkn)
        {
            try
            {
                var ecgCount = 0.0;
                var tiCount = 0.0;
                const double conversionFactor = (double) 5/1023;
                const double currentConversion = 9982.0;
                const double ecgVoltageOffset = 2.22;
                const double tiVoltageOffset = 2.22;
                const double diodeVoltageDrop = 0.188;
                const double totalVoltageGain = 122;

                while (true)
                {
                    tkn.ThrowIfCancellationRequested();
                    Tuple<string, double, double> data;
                    if (!dataQueue.TryPeek(out data)) continue;
                    if (data.Item1 == @"V")
                    {
                        ecgCount++;
                        dataQueue.TryDequeue(out data);
                        ecgHolder.Enqueue(new DataPoint(ecgCount/500, (data.Item3*conversionFactor - ecgVoltageOffset) * 8.197));
                    }
                    else
                    {
                        Tuple<string, double, double> data2;
                        if (dataQueue.Count <= 1) continue;
                        if (!dataQueue.TryDequeue(out data)) continue;
                        if (!dataQueue.TryDequeue(out data2)) continue;
                        tiCount++;
                        var value = (data2.Item3 * conversionFactor + diodeVoltageDrop);
                        value = value / currentConversion;
                        value = (data.Item3 * conversionFactor - tiVoltageOffset) / totalVoltageGain / value;
                        tiHolder.Enqueue(new DataPoint(tiCount/100, value));
                    }
                }
            }
            catch (Exception e)
            {
                Debug.Print(e.StackTrace);
            }
        }
    }
}
