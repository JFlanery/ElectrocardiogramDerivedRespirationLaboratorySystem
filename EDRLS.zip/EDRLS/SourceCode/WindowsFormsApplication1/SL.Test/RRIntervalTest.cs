﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SL.Test
{
	[TestClass]
	public class RRIntervalTest
	{
		[TestMethod]
		public void CalculateInterval()
		{
			var points = PeakFinderImplTest.loadPoints();
			var rrInterval = new RRInterval(points[0],points[10]);
			Assert.AreEqual(rrInterval.Interval, 10.0);
		}
	}
}
