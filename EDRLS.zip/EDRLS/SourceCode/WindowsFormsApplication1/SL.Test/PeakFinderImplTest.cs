﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SL;
using System.Collections.Generic;

namespace SL.Test
{
	[TestClass]
	public class PeakFinderImplTest
	{
		public static IList<RRInterval.Point> loadPoints()
		{
			return new List<RRInterval.Point>()
			{
				new RRInterval.Point(0.0, 0.0),
				new RRInterval.Point(1.0, 1.0),
				new RRInterval.Point(2.0, 2.0),
				new RRInterval.Point(3.0, 3.0),
				new RRInterval.Point(4.0, 0.0),
				new RRInterval.Point(5.0, 2.0),
				new RRInterval.Point(6.0, 4.0),
				new RRInterval.Point(7.0, 5.0),
				new RRInterval.Point(8.0, 2.0),
				new RRInterval.Point(9.0, 2.0),
				new RRInterval.Point(10.0, 0.0),
				new RRInterval.Point(11.0, 1.0),
				new RRInterval.Point(12.0, 0.0),
				new RRInterval.Point(13.0, 1.0),
				new RRInterval.Point(14.0, 1.0),
				new RRInterval.Point(15.0, 2.0),
				new RRInterval.Point(16.0, 0.0),
				new RRInterval.Point(17.0, 8.0)
			};
		}

		[TestMethod]
		public void PeakFinder()
		{
			var result = PeakFinderImpl.FindPeaks(loadPoints(), 0, 0);
			Assert.AreEqual(result.Count, 5);
			result = PeakFinderImpl.FindPeaks(loadPoints(), 2, 0);
			Assert.AreEqual(result.Count, 4);
		}

		[TestMethod]
		public void ZScore()
		{
			var result = PeakFinderImpl.ZScore(loadPoints());
			result = PeakFinderImpl.ZScore(loadPoints(), 0);
			result = PeakFinderImpl.ZScore(loadPoints(), 0, 0);
		}
		
		[TestMethod]
		public void StdDev()
		{
			var result = PeakFinderImpl.StdDev(loadPoints());
			result = PeakFinderImpl.StdDev(loadPoints(), 0);
		}

		[TestMethod]
		public void Mean()
		{
			var result = PeakFinderImpl.Mean(loadPoints());
			Assert.AreEqual(result, 1.89, 0.01); 
		}

		[TestMethod]
		public void CalculateSlope()
		{
			var points = loadPoints();
			var result = PeakFinderImpl.CalculateSlope(points[0], points[1]);
			Assert.AreEqual(result, 1.0);
		}

	}
}
